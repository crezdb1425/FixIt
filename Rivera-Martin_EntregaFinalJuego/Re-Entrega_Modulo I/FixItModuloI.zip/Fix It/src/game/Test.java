package game;


public class Test {

	public static void main(String[] args) {
		Juego j = new Juego();
		j.comenzar();
		while (!j.isOver()) {
			j.actualizar();
			
			for (int i=0;i<3;i++) {
				j.repararVentana(FelixJr.getInstancia().getPos());
				System.out.println("Felix Jr di� tres martillazos");
				}
			if (FelixJr.getInstancia().getPos().getX() < 4) {
				FelixJr.getInstancia().setProxMov(Pos.DERECHA);
				System.out.println("Felix se mueve a la derecha");
			}
			if (FelixJr.getInstancia().getPos().getX() < 4) {
				FelixJr.getInstancia().setProxMov(Pos.DERECHA);
				System.out.println("Felix se mueve a la derecha");
			}
			j.actualizar();
			if (j.getTiempo() == 3) {
				FelixJr.getInstancia().setProxMov(Pos.ARRIBA);
				System.out.println("Felix Jr se mueve hacia arriba");
			}
			if (j.getTiempo() == 4) {
				FelixJr.getInstancia().setProxMov(Pos.IZQUIERDA);
				System.out.println("Felix Jr se mueve a la izquierda");
			}
			
		}
	}
}
