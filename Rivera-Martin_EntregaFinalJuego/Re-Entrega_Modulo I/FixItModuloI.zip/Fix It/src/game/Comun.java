package game;

import java.util.Random;

public class Comun extends Ventana {
	private boolean pastel;

	public boolean isPastel() {
		return pastel;
	}

	public void setPastel(boolean pastel) {
		this.pastel = pastel;
	}
	
	/**
	 * Constructor que inicializa las molduras, maceteros y pastel en falso, posiciona la ventana, reserva memoria para sus paneles
	 * y los inicializa como sano.
	 * @param pos
	 * @param panel
	 */
	public Comun(Posicion pos) {
		super(pos);
		this.setMoldura(false);
		this.setMacetero(false);
		this.setPastel(false);
		this.setPos(pos);
		Panel [] panel = new Panel[2];
		for(int i=0; i<panel.length;i++) {
			panel[i]=new Panel();
			panel[i].setEstado(Estado.SANO);
		}
		this.setPaneles(panel);
	}

	/**
	 * M�todo toString que devuelve "Comun"
	 */
	public String toString() {
		return "Comun";
	}

	
	
	/**
	 * M�todo que repara los paneles. Si el panel inferior(par) no est� sano, se llama al metodo reparar() de la superclase ventana
	 * Sino, se pregunta por el superior, si no esta sano, se sigue la misma logica que antes y ademas suma 100ptos y se resta la cantidad
	 * de ventanas rotas actual del edificio
	 * 
	 */
	public void reparar () {
		if (this.getPaneles()[0].getEstado() != Estado.SANO) {
			this.reparar(0);
		}
		else {
			if (this.getPaneles()[1].getEstado() != Estado.SANO) {
				this.reparar(1);
				Juego.getInstancia().sumarPuntos(100);
				Edificio.getInstancia().setCantVentanasRotasActual(Edificio.getInstancia().getCantVentanasRotasActual() - 1);
				}
			}
		}
	
	
	/**
	 * M�todo que inicializa el estado de los paneles de manera aleatoria
	 */
	public void inicializarPaneles() {
		Random r = new Random(System.currentTimeMillis());
		int cantP = r.nextInt(2)+1;
		int posPanel = r.nextInt(2);
		
		switch(cantP){
		case (1):{
			this.getPaneles()[posPanel].romperPanel();
			break;
		}
		case (2):{
			this.getPaneles()[0].romperPanel();
			this.getPaneles()[1].romperPanel();
		}
		}
	}
	
	
	/*/////////////////////// Se agrego ////////////////////////////////////*/
	
	/**
	 * M�todo que devuelve un boolean si el panel inferior esta completamente roto
	 * @return boolean
	 */
	public boolean puedeAparecerNicelander() {
		if (this.getPaneles()[0].getEstado() == Estado.ROTO) {
			return true;
		}
		else 
			return false;
	}
	
	
	
	/**
	 * M�todo que devuelve true si es posible moverse para Felix desde la ventana en la Pos dir,
	 * segun si hay obstaculo o no hacia arriba o hacia abajo
	 * Complementa al m�todo puedeMoverse() de Felix
	 * @param dir direccion en la que se deberia mover felix
	 * @return boolean
	 */
	public boolean puedoSalir (Pos dir) {
		switch(dir) {
		case ARRIBA:{
			if(this.isMoldura())
				return false;
			else
				return true;
		}
		case ABAJO:{
			if(this.isMacetero())
				return false;
			else
				return true;
		}
		default: 
			return true;
		}
	}
	
	
	/**
	 * M�todo que devuelve true si es posible moverse para Felix hacia la ventana en la Pos dir, 
	 * segun si hay obstaculo o no hacia arriba o hacia abajo
	 * Complementa al m�todo puedeMoverse() de Felix
	 * @param dir direccion en la que se deberia mover felix
	 * @return boolean
	 */
	public boolean puedoEntrar (Pos dir) {
		switch(dir) {
		case ARRIBA:{
			if(this.isMacetero())
				return false;
			else
				return true;
		}
		case ABAJO:{
			if(this.isMoldura())
				return false;
			else
				return true;
		}
		default: 
			return true;
		}
	}
	
	
	
}
