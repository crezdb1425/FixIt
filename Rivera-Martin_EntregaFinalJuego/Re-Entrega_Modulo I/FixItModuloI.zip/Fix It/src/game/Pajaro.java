package game;


public class Pajaro extends Individuo{

	/**
	 * Constructor de pajaro que de manera aleatoria elige por cual fila de ventanas se va a mover
	 */
	public Pajaro () {
		super();
		Seccion sec = Edificio.getInstancia().getSeccionActual();
		double ran = Math.random()*3;
		Posicion posi = new Posicion(); 
		if (sec == Seccion.MEDIO) {
			if (ran < 1) {
				posi.setY(3);
			}
			else {
				if (ran < 2) {
					posi.setY(4);
				}
				else {
					posi.setY(5);
				}
			}
		
		}
		else {
			if (ran < 1) {
				posi.setY(6);
			}
			else {
				if (ran < 2) {
					posi.setY(7);
				}
				else {
					posi.setY(8);
				}
		}
	}
		this.setPos(posi);
}

	
	/**
	 * M�todo toString que devuelve "Pajaro"
	 * @return String
	 */
	public String toString () {
		return "Pajaro";
	}
	
	
	/**
	 * M�todo que, a partir de la fila de ventana inicial indicada por inicializar(), decide 
	 * si a apartir de la derecha o izquierda aparece y comienza a avanzar 
	 */
	public void mover () {
		if (Edificio.getInstancia().getSeccionActual() != Seccion.PLANTABAJA){
			if (Math.random() > 0.9) {
				Posicion p = new Posicion();
				if (Math.random() < 0.5) {
					p.setX(0);
					for (int i = 0; i < 4; i++) {
						this.getPos().calcularMovimiento(Pos.DERECHA);
					}
				}
				else {
					p.setX(4);
					for (int i = 0; i < 4; i++) {
						this.getPos().calcularMovimiento(Pos.IZQUIERDA);
					}
				}
			}
		}
	}
	
	

	/**
	 * M�todo que corrobora si su posicion coincide con la de Felix
	 * @param p posicion de felix
	 * @return boolean true, si coincide, false caso contrario
	 */
	public boolean colision (Posicion p) {
		if (p.equals(this.getPos())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
}