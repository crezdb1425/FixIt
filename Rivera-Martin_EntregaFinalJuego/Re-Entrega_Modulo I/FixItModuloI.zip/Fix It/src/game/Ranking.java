package game;

import java.util.Scanner;

public class Ranking {
	private int puntos;
	private String nombre;
	
	
	public int getPuntos() {
		return puntos;
	}
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	private static Ranking instancia;
	
	public static Ranking getInstancia() {
		return instancia;
	}
	
	
	public Ranking() {
		this.puntos=0;
	}
	
	
	/**
	 * M�todo encargado de guardar el puntaje actual en la lista top 5 si corresponde
	 * @param puntaje pasado por juego que es el que lleva el conteo del puntaje de la partida actual
	 */
	public void guardarPuntaje(int puntaje) {																
		int pos=-1;
		Scanner in= new Scanner(System.in);
		if (puntaje >= Juego.getInstancia().getCincoMejores()[4].getPuntos()) {
			for(int i=0;i<5;i++) {
				if(puntaje >= Juego.getInstancia().getCincoMejores()[i].getPuntos()) {
					pos=i;
				}
			}
			if(pos!=-1) {
				for(int j=4;j>pos;j--) {
					Juego.getInstancia().getCincoMejores()[j].setPuntos(Juego.getInstancia().getCincoMejores()[j-1].getPuntos());
				}
				Juego.getInstancia().getCincoMejores()[pos].setPuntos(puntaje);
				System.out.println("Felicidades! Usted ha ingresado al TOP 5 de los mejores puntajes!");
				System.out.println("Nombre: ");
				Juego.getInstancia().getCincoMejores()[pos].setNombre(in.next());
			}
		}
		in.close();
	}
	
}
