package game;

import java.lang.Math;
import java.util.Random;

public class Edificio {
	private Seccion seccionActual;
	private int ventanasRotas;            
	private int cantVentanasRotasActual;  		
	private Ventana dimensionTotal [][];
	private int ventanasAbiertas ;
	private int cantMolduras;
	private int cantMaceteros;
	
	private static Edificio instancia = new Edificio();				
	
	public static Edificio getInstancia() {							
		return instancia;											
	}
	
	/**
	 * Constructor de Edificio.
	 * Inicializa la seccion actual en plantabaja, las cantidades iniciales de ventanas rotas, abiertas, molduras y maceteros
	 * Reserva memoria para la matriz de ventanas que conforman el edificio
	 * Elige de manera aleatoria las ventanas comunes/conHojas
	 * Inicializa las ventanas semicirculares en su posicion correspondiente
	 */
	public Edificio () {
		int cantidadesIniciales = 10;
		int cantidadFilas = 9;
		int cantidadColumnas = 5;
		this.seccionActual= Seccion.PLANTABAJA;						
		this.ventanasRotas= cantidadesIniciales;							
		this.cantVentanasRotasActual= cantidadesIniciales;							
		Ventana dimensionTotal [][]= new Ventana [cantidadFilas][cantidadColumnas];		
		this.dimensionTotal= dimensionTotal;						
		this.ventanasAbiertas= cantidadesIniciales;								
		this.cantMolduras= cantidadesIniciales;									
		this.cantMaceteros= cantidadesIniciales;								
		int x,y;
		Random r = new Random(System.currentTimeMillis());
		for(int i=0;i<22;i++) {
			x= r.nextInt(cantidadFilas);
			y= r.nextInt(cantidadColumnas);
			while(dimensionTotal[x][y] != null) {
				x= r.nextInt(cantidadFilas);
				y= r.nextInt(cantidadColumnas);
			}
			Posicion p=new Posicion();
			p.setX(x);
			p.setY(y);
			dimensionTotal[x][y]=new ConHojas(p);
		}
		for(int j=0;j<23;j++) {
			x= r.nextInt(cantidadFilas);
			y= r.nextInt(cantidadColumnas);
			while(dimensionTotal[x][y]!=null) {
				x= r.nextInt(cantidadFilas);
				y= r.nextInt(cantidadColumnas);
			}
			Posicion p=new Posicion();
			p.setX(x);
			p.setY(y);
			dimensionTotal[x][y]=new Comun(p);
		}
		Posicion p=new Posicion();
		x=0;
		y=2;
		p.setX(x);
		p.setY(y);
		dimensionTotal[0][2]= new SemiCircularPB(p);
		x=1;
		Posicion ps =new Posicion();
		ps.setX(x);
		ps.setY(y);
		dimensionTotal[1][2]= new SemiCircular(p);
		for (int i=0; i<9; i++) {
			for (int j=0; j<5; j++) {
				p.setX(i);
				p.setY(j);
				dimensionTotal[i][j].setPos(p);
			}
		}
		
	}
	

	public int getVentanasAbiertas() {
		return ventanasAbiertas;
	}

	public void setVentanasAbiertas(int ventanasAbiertas) {
		this.ventanasAbiertas = ventanasAbiertas;
	}

	public int getCantMolduras() {
		return cantMolduras;
	}

	public void setCantMolduras(int cantMolduras) {
		this.cantMolduras = cantMolduras;
	}

	public int getCantMaceteros() {
		return cantMaceteros;
	}

	public void setCantMaceteros(int cantMaceteros) {
		this.cantMaceteros = cantMaceteros;
	}

	public Seccion getSeccionActual() {
		return seccionActual;
	}

	public void setSeccionActual(Seccion seccionActual) {
		this.seccionActual = seccionActual;
	}

	public int getVentanasRotas() {
		return ventanasRotas;
	}

	public void setVentanasRotas(int VentanasRotas) {
		this.ventanasRotas = VentanasRotas;
	}

	public int getCantVentanasRotasActual() {
		return cantVentanasRotasActual;
	}

	public void setCantVentanasRotasActual(int VentanasRotasActual) {
		this.cantVentanasRotasActual = VentanasRotasActual;
	}

	public Ventana[][] getDimensionTotal() {
		return dimensionTotal;
	}

	public void setDimensionTotal(Ventana[][] dimensionTotal) {
		this.dimensionTotal = dimensionTotal;
	}
	
	public void repararVentana(Posicion pos) {
		this.dimensionTotal[pos.getX()][pos.getY()].reparar();
	}
	
	public void cambiarSeccion(Seccion seccion) {
		this.seccionActual=seccion;
	}

	
	/**
	 * Metodo que rompe de manera aleatoria las ventanas, misma cantidad en cada seccion. Todo el edificio junto.
	 * Accede por seccion preguntando si no est� rota dicha ventana, con un random decide si romperla o no.
	 */
	public void inicializarVentanas() {
		int cantSecciones = 3;	
		/* Inicializo la seccion 1 */
		int l= (int) this.ventanasRotas/cantSecciones;
		while(l>0) {
			for(int j=0;j<3;j++) {
				for(int k=0;k<5;k++) {
					if(!this.dimensionTotal[j][k].isEstaRota()) {
						if(Math.random()<0.5) {
							this.dimensionTotal[j][k].setEstaRota(true);
							this.dimensionTotal[j][k].inicializarPaneles();
							l--;
						}
					}
				}
			}
		}
		/* Inicializo la seccion 2 */
		int m= (int) this.ventanasRotas/cantSecciones;
		while(m>0) {
			for(int j=3;j<6;j++) {
				for(int k=0;k<5;k++) {
					if(!this.dimensionTotal[j][k].isEstaRota()) {
						if(Math.random()<0.5) {
							this.dimensionTotal[j][k].setEstaRota(true);
							this.dimensionTotal[j][k].inicializarPaneles();
							m--;
						}
					}
				}
			}
		}
		/* Inicializo la seccion 3 */
		int i= (int) this.ventanasRotas/cantSecciones;
		while(i>0) {
			for(int j=6;j<9;j++) {
				for(int k=0;k<5;k++) {
					if(!this.dimensionTotal[j][k].isEstaRota()) {
						if(Math.random()<0.5) {
							this.dimensionTotal[j][k].setEstaRota(true);
							this.dimensionTotal[j][k].inicializarPaneles();
							i--;
						}
					}
				}
			}
		}
	}
	
	/**
	 * M�todo que inicializa de manera aleatoria las molduras y los maceteros, utilizando la misma l�gica que inicializarVentanas()
	 */
	public void inicializarMaceteroYMolduras () {																			
		/* Molduras */
		int i=this.cantMolduras;
		while(i>0) {
			for(int j=0;j<9;j++) {
				for(int k=0; k<5;k++) {
					if( !(this.dimensionTotal[j][k].toString().equals("Semi")) && (!this.dimensionTotal[j][k].isMoldura()) ) {
						if(Math.random()<0.5)
							this.dimensionTotal[j][k].setMoldura(false);
						else {
							this.dimensionTotal[j][k].setMoldura(true);
							i--;
						}
					}
				}	
			}	
		}
		/* Maceteros */
		int m=this.cantMaceteros;
		while(m>0) {
			for(int j=0;j<9;j++) {
				for(int k=0; k<5;k++) {
					if(!(this.dimensionTotal[j][k].toString().equals("Semi"))&&(this.dimensionTotal[j][k].isMacetero()!=true)) {
						if(Math.random()<0.5)
							this.dimensionTotal[j][k].setMacetero(false);
						else {
							this.dimensionTotal[j][k].setMacetero(true);
							m--;
						}
					}
				}	
			}	
		}
	}
	
	
	/**
	 * M�todo que le indica al Nicelander qu� ventana tiene el panel inferior completamente roto para poder aparecer
	 * @return Ventana donde podria aparecer el nicelander
	 */
	public Ventana dondeAparecer() {
		switch (this.seccionActual) {
		case PLANTABAJA:
			return this.buscarVentana(Seccion.getLimiteInferiorPB(), Seccion.getLimiteSuperiorPB());
		case MEDIO:
			return this.buscarVentana(Seccion.getLimiteInferiorM(), Seccion.getLimiteSuperiorM());
		case TERRAZA:
			return this.buscarVentana(Seccion.getLimiteInferiorT(), Seccion.getLimiteSuperiorT());
		default:
			return null;
		}
	}
	
	/**
	 * M�todo que complementa al m�todo dondeAparecer()
	 * Busca la ventana con el panel inferior completamente roto
	 * @param infCol limite inferior de columna en la matriz segun seccion actual
	 * @param supCol limite superior 
	 * @return Ventana
	 */
	public Ventana buscarVentana (int infCol, int supCol) {
		for (int i=Seccion.getLimiteIzquierdo(); i<Seccion.getLimiteDerecho(); i++) {
			for (int j=infCol; j<supCol; j++) {
				if (this.getDimensionTotal()[i][j].puedeAparecerNicelander()) {
					return this.getDimensionTotal()[i][j];
				}
			}
		}
		return null;
	}
}
