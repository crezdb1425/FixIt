package game;


public class Posicion  {
	private int x;
	private int y;
	
	
	public int getX() {
		return x;
	}


	public void setX(int x) {
		this.x = x;
	}


	public int getY() {
		return y;
	}


	public void setY(int y) {
		this.y = y;
	}

	@Override
	public boolean equals (Object o) {
		Posicion p = (Posicion)o; 
		if((this.x==p.getX())&&(this.y==p.getY()))
			return true;
		else
			return false;
	}
	
	/**
	 * M�todo que incrementa en el eje de las x o de las y segun corresponda al "movimiento"
	 * pasado por paramentro
	 * @param p direccion en la que se quiere mover felix
	 */
	public void calcularMovimiento(Pos p) {	
		switch (p) {
		case DERECHA:
			this.setX(this.getX()+1);			
			break;
		case IZQUIERDA:
			this.x -= 1;
			break;
		case ARRIBA:
			this.y += 1;
			break;
		case ABAJO:
			this.y -= 1;

		}
	}
}
