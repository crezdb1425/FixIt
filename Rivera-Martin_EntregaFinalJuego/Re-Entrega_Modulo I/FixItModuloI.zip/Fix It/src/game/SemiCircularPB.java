package game;

import java.util.Random;

public class SemiCircularPB extends Ventana {

	public SemiCircularPB(Posicion pos) {
		super(pos);
		Panel [] panel = new Panel[4];
		for(int i=0; i<panel.length;i++) {
			panel[i]=new Panel();
			panel[i].setEstado(Estado.SANO);
		}
		this.setPaneles(panel);
	}

	
	
	/**
	 * M�todo que repara los paneles dede el mas inferior a la izquierda, hasta el mas superior a la derecha
	 * 
	 */
	public void reparar () {
		if (this.getPaneles()[0].getEstado() != Estado.SANO) {
			this.reparar(0);
		}
		else {
			if (this.getPaneles()[2].getEstado() != Estado.SANO) {
				this.reparar(2);
			}
			else {
				if (this.getPaneles()[1].getEstado() != Estado.SANO) {
					this.reparar(1);
				}
				else {
					if (this.getPaneles()[3].getEstado() != Estado.SANO) {
						this.getPaneles()[3].setCant_martillazos(this.getPaneles()[3].getCant_martillazos() + 1);
						if (this.getPaneles()[3].getCant_martillazos() == 2) {
							this.getPaneles()[3].setEstado(Estado.SANO);
							Juego.getInstancia().sumarPuntos(100);
							Edificio.getInstancia().setCantVentanasRotasActual(Edificio.getInstancia().getCantVentanasRotasActual() - 1);
						}
					 }
				}
			}
		}
	}
	
	
	
	public String toString() {
		return "Semi";
	}
	
	
	/**
	 * M�todo que rompe los paneles de manera aleatoria
	 */
	public void inicializarPaneles() {
		Random r =new Random(System.currentTimeMillis());
		int cantP = r.nextInt(3)+1;
		while(cantP>0) {
			for(int i=0; i<this.getPaneles().length;i++) {
				if(this.getPaneles()[i].getEstado().equals(Estado.SANO))
					if(Math.random()<0.5) {
						this.getPaneles()[i].romperPanel();
						cantP--;
					}		
			}
		}
	}



	@Override
	public boolean puedoSalir(Pos dir) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public boolean puedoEntrar(Pos dir) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	

}
