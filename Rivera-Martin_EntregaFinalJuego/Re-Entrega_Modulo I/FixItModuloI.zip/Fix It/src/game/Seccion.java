package game;

public enum Seccion {
	PLANTABAJA, MEDIO, TERRAZA;
	

	
	private static int limiteDerecho = 4;
	private static int limiteIzquierdo = 0;
	private static int limiteInferiorPB = 0;
	private static int limiteSuperiorPB = 2;
	private static int limiteInferiorM = 3;
	private static int limiteSuperiorM = 5;
	private static int limiteInferiorT = 6;
	private static int limiteSuperiorT = 8;
	
	
	
	public static int getLimiteDerecho() {
		return limiteDerecho;
	}
	public static void setLimiteDerecho(int limiteDerecho) {
		Seccion.limiteDerecho = limiteDerecho;
	}
	public static int getLimiteIzquierdo() {
		return limiteIzquierdo;
	}
	public static void setLimiteIzquierdo(int limiteIzquierdo) {
		Seccion.limiteIzquierdo = limiteIzquierdo;
	}
	
	public static int getLimiteInferiorPB() {
		return limiteInferiorPB;
	}
	public static void setLimiteInferiorPB(int limiteInferiorPB) {
		Seccion.limiteInferiorPB = limiteInferiorPB;
	}
	
	public static int getLimiteSuperiorPB() {
		return limiteSuperiorPB;
	}
	public static void setLimiteSuperiorPB(int limiteSuperiorPB) {
		Seccion.limiteSuperiorPB = limiteSuperiorPB;
	}
	public static int getLimiteInferiorM() {
		return limiteInferiorM;
	}
	public static void setLimiteInferiorM(int limiteInferiorM) {
		Seccion.limiteInferiorM = limiteInferiorM;
	}
	public static int getLimiteSuperiorM() {
		return limiteSuperiorM;
	}
	public static void setLimiteSuperiorM(int limiteSuperiorM) {
		Seccion.limiteSuperiorM = limiteSuperiorM;
	}
	public static int getLimiteInferiorT() {
		return limiteInferiorT;
	}
	public static void setLimiteInferiorT(int limiteInferiorT) {
		Seccion.limiteInferiorT = limiteInferiorT;
	}
	public static int getLimiteSuperiorT() {
		return limiteSuperiorT;
	}
	public static void setLimiteSuperiorT(int limiteSuperiorT) {
		Seccion.limiteSuperiorT = limiteSuperiorT;
	}
	

	
	
}
