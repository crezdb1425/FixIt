package game;



/* Por convenci�n se decidio que los paneles inferiores son los pares y los superiores los impares */



public abstract class Ventana {
	private boolean moldura;
	private boolean macetero;
	private Posicion pos;
	private Panel paneles[];
	private boolean estaRota;
	
	
	public Ventana(Posicion pos) {
		this.setMoldura(false);
		this.setMacetero(false);
		this.setPos(pos);
	};
	
	public boolean isEstaRota() {
		return estaRota;
	}

	public void setEstaRota(boolean estaRota) {
		this.estaRota = estaRota;
	}
	
	public boolean isMoldura() {
		return moldura;
	}
	public void setMoldura(boolean moldura) {
		this.moldura = moldura;
	}
	public boolean isMacetero() {
		return macetero;
	}
	public void setMacetero(boolean macetero) {
		this.macetero = macetero;
	}
	public Posicion getPos() {
		return pos;
	}
	public void setPos(Posicion pos) {
		this.pos = pos;
	}
	public Panel[] getPaneles() {
		return paneles;
	}
	public void setPaneles(Panel[] paneles) {
		this.paneles = paneles;
	}
	
	
	/**
	 * M�todo que devuelve false por default pero que es sobreescrito en las ventanas donde si es posible que aparezca un Nicelander
	 * @return true, si puede aparecer, false caso contrario
	 */
	public boolean puedeAparecerNicelander() {			
		return false;
	}
	

	/**
	 * M�todo que repara los paneles, este es igual a todas los tipos de ventanas y complementa
	 * al m�todo reparar(pos)
	 * Recibe el numero de la posicion del panel a reparar y modifica su estado a sano, tambien suma 100 puntos
	 * @param panel, numero de la posicion del panel a reparar
	 */
	public void reparar (int panel) {
		this.getPaneles()[panel].setCant_martillazos(this.getPaneles()[panel].getCant_martillazos() + 1);
		if (this.getPaneles()[panel].getCant_martillazos() == 2) {
			this.getPaneles()[panel].setEstado(Estado.SANO);
			Juego.getInstancia().sumarPuntos(100);
		}
	}
	
	
	public abstract void reparar ();
	
	public abstract boolean puedoSalir (Pos dir);
	
	public abstract boolean puedoEntrar (Pos dir);
	
	
	public abstract void inicializarPaneles();
	
	
}
