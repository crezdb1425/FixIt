package game;


/* Esta clase fu� hecha por completo en esta segunda entrega */

public class Nicelander extends Individuo{
	private boolean aparecer;
	private int contador;	
	private Ventana ventana;

	public Nicelander () {
		Posicion pos= new Posicion();
		pos.setX(0);
		pos.setY(0);
		this.setPos(pos);
		this.aparecer = false;
		this.contador = 5;
		this.ventana = null;
	}

	
	public Ventana getVentana() {
		return ventana;
	}

	public void setVentana(Ventana ventana) {
		this.ventana = ventana;
	}

	public boolean isAparecer() {
		return aparecer;
	}

	public void setAparecer(boolean aparecer) {
		this.aparecer = aparecer;
	}

	public int getContador() {
		return contador;
	}

	public void setContador(int contador) {
		this.contador = contador;
	}

	/**
	 * M�todo toString que devuelve "Nicelander"
	 */
	public String toString () {
		return "Nicelander";
	}
	
	/**
	 * M�todo que se ejecuta en cada instante, verificando si tiene una ventana en la que pueda aparecer,
	 * Con un random decide si aparece o no,
	 * Si no tiene ventana asignada, busca una disponible con el panel inferior completamente roto
	 */
	public void actualizar() {
		if (ventana != null) {
			if (!aparecer) {
				if(Math.random() < 0.5) {
					this.aparecer = true;
				}
			}
		}
		else {	
			this.setVentana(Edificio.getInstancia().dondeAparecer());
		}
	}
	
	
	/**
	 * M�todo que corrobora si tiene que aparecer (o esta visible) y decrementa el tiempo restante como visible
	 * Cuando deba desaparecer coloca el pastel, reinicia el contador para la proxima vez que aparezca y desaparece
	 */
	public void mover () {
		if (aparecer) {
			if (contador != 0) {
				contador--;
			}
			else {
				Pastel pastel = new Pastel();
				pastel.setPos(this.getPos());
				pastel.setAparecer(true);
				this.contador = 5;
				this.aparecer = false;
			}
		}
	}
	
	
	/**
	 * M�todo que verifica si colisiono con Felix, no aplicable en Nicelander, por eso retorna false siempre
	 * @param p posicion de felix
	 * @return boolean true, si coincide, false caso contrario
	 */
	public boolean colision (Posicion p) {
		return false;
	}

}
