package game;

import java.util.Random;

public class SemiCircular extends Ventana{

	/**
	 * Constructor que inicializa en false los maceteros y molduras, carga la posicion de la ventana
	 * Reserva memoria para 8 paneles
	 * @param pos posicion de la ventana
	 * @param panel panel correspondiente
	 */
	public SemiCircular(Posicion pos) {
		super(pos);
		Panel [] panel = new Panel[8];
		for(int i=0; i<panel.length;i++) {
			panel[i]=new Panel();
			panel[i].setEstado(Estado.SANO);
		}
		this.setPaneles(panel);
	}

	

	/**
	 * M�todo que repara los paneles a partir de los inferiores mas a la izquierda a los 
	 * superiores mas a la derecha
	 */
	public void reparar () {
		if (this.getPaneles()[0].getEstado() != Estado.SANO) {
			this.reparar(0);
		}
		else {
			if (this.getPaneles()[2].getEstado() != Estado.SANO) {
				this.reparar(2);
			}
			else {
				if (this.getPaneles()[4].getEstado() != Estado.SANO) {
					this.reparar(4);
				}
				else {
					if (this.getPaneles()[6].getEstado() != Estado.SANO) {
						this.reparar(6);
					 }
					else {
						if (this.getPaneles()[1].getEstado() != Estado.SANO) {
							this.reparar(1);
						}
						else {
							if (this.getPaneles()[3].getEstado() != Estado.SANO) {
								this.reparar(3);
							}
							else {
								if (this.getPaneles()[5].getEstado() != Estado.SANO) {
									this.getPaneles()[5].setCant_martillazos(this.getPaneles()[5].getCant_martillazos() + 1);
									if (this.getPaneles()[5].getCant_martillazos() == 2) {
										this.getPaneles()[5].setEstado(Estado.SANO);
										Juego.getInstancia().sumarPuntos(100);
										Juego.getInstancia().getEdif().setCantVentanasRotasActual(Juego.getInstancia().getEdif().getCantVentanasRotasActual() - 1);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	public String toString() {
		return "Semi";
	}

	
	/**
	 * M�todo que rompe la cantidad de paneles de manera aleatoria
	 */
	public void inicializarPaneles() {
		Random r =new Random(System.currentTimeMillis());
		int cantP = r.nextInt(7)+1;
		while(cantP<0) {
			for(int i=0; i<this.getPaneles().length;i++) {
				if(this.getPaneles()[i].getEstado()==Estado.SANO)
					if(Math.random()<0.5) {
						this.getPaneles()[i].romperPanel();
						cantP--;
					}		
			}
		}
	}





	@Override
	public boolean puedoSalir(Pos dir) {
		// TODO Auto-generated method stub
		return false;
	}





	@Override
	public boolean puedoEntrar(Pos dir) {
		// TODO Auto-generated method stub
		return false;
	}


		
}
