package game;

public enum Estado {
	SANO, MEDIOROTO, ROTO;
}
