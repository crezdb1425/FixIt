package game;

public class Ralph extends Individuo{
	private int maxLadrillos;  
	private Ladrillo ladri;									
	private int cantLadrillos;			/* ladrillos que le quedan (maxLadrillos - los que vaya usando) */
	private int contador;										
	
	private static Ralph instanncia = new Ralph();				
	
	public static Ralph getInstancia() {						
		return instanncia;
	}
	
	
	public Ralph () {
		super();
		this.maxLadrillos=40;
		this.ladri=new Ladrillo();
		this.cantLadrillos=40;
		this.contador=0;
	}
	
	
	public int getCantLadrillos() {
		return cantLadrillos;
	}
	public void setCantLadrillos(int cantLadrillos) {
		this.cantLadrillos = cantLadrillos;
	}
	
	public int getMaxLadrillos() {
		return maxLadrillos;
	}
	public void setMaxLadrillos(int maxLadrillos) {
		this.maxLadrillos = maxLadrillos;
	}
	
	public Ladrillo getLadri() {
		return ladri;
	}
	public void setLadri(Ladrillo ladri) {
		this.ladri = ladri;
	}
		
	/**
	 * M�todo que mueve a Ralph aleatoriamente de izquierda a derecha
	 */
	public void mover (){
		double ran = Math.random();
		this.setPos(new Posicion());
		if(ran < 0.5){
			if(this.getPos().getX()==Seccion.getLimiteIzquierdo()){
				this.getPos().calcularMovimiento(Pos.DERECHA);
				this.getPos().calcularMovimiento(Pos.DERECHA);
			        }
			else
				this.getPos().calcularMovimiento(Pos.IZQUIERDA);
		}
		else {
			if (this.getPos().getX()==Seccion.getLimiteDerecho()){
				this.getPos().calcularMovimiento(Pos.IZQUIERDA);
				this.getPos().calcularMovimiento(Pos.IZQUIERDA);
				}
			else
				this.getPos().calcularMovimiento(Pos.DERECHA);
		}
	}
	
	
	/**
	 * M�todo que incrementa el contador y cuando este llega a 5, se reinicia en 0 y Ralph tira 3 ladrillos
	 */
	public void actualizar () {
		contador += 1;
		if (contador == 5) {
			for(int i=0; i<3; i++) {
				this.tirarLadrillo();
			}
			contador = 0;
		}
	}

	/**
	 * M�todo que verifica la colision entre Felix y el resto de los individuos pero en este caso no es aplicable,
	 * retorna false siempre
	 * @param p posicion de felix
	 * @return boolean
	 */
	public boolean colision(Posicion p) {
		return false;
	}
	
	/**
	 * M�todo que complementa al metodo actualizar() y decrementa la cantidad de ladrillos actual e indica a ladrillos que caigan
	 */
	public void tirarLadrillo(){
		System.out.println("Ralph tira ladrillos");
		this.cantLadrillos--;
		this.ladri.mover();
	}


}
