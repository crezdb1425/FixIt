package game;


public class FelixJr extends Individuo{
	private int vidas;
	private boolean inmunidad;
	private Pos proxMov;									
	private int inmuni;
	
	
	
	private static FelixJr instancia = new FelixJr();				
	
	private FelixJr () {
		super();
		this.vidas = 3;
	}
	
	public static FelixJr getInstancia() {						 	
		return instancia;	
	}

	
	public int getInmuni() {
		return inmuni;
	}
	public void setInmuni(int inmuni) {
		this.inmuni = inmuni;
	}
	public int getVidas() {
		return vidas;
	}
	public void setVidas(int vidas) {
		this.vidas = vidas;
	}
	
	public Pos getProxMov() {
		return proxMov;
	}

	public void setProxMov(Pos proxMov) {
		this.proxMov = proxMov;
	}
	
	public boolean isInmunidad() {
		return inmunidad;
	}
	public void setInmunidad(boolean inmunidad) {
		this.inmunidad = inmunidad;
	}
	
	
	public void repararVentana() {
		Juego.getInstancia().repararVentana(this.getPos());
	}
	
	/**
	 * M�todo que decrementa vida a Felix y si estas llegan a 0, el juego termina, sino se reinicia el nivel
	 */
	public void perderVida () {
		this.vidas -= 1;
		if (this.vidas == 0) {
			Juego.getInstancia().gameOver();
		}
		else 
			Juego.getInstancia().inicializarNivel();
	}
	
	/**
	 * M�todo que le da inmunidad a felix, inicializa el contador inmuni
	 */
	public void comerPastel() {
		this.inmunidad = true;
		this.inmuni = 5;
	}
		

	/**
	 * M�todo que verifica que Felix pueda moverse segun si hay macetero, moldura (en el caso de ventana comun)
	 * O si ademas tiene hojas (en el caso de ventana con hojas)
	 * @param mov movimiento que se le pide a felix
	 * @return boolean true, si es posible moverse, false caso contrario
	 */
	public boolean puedeMoverse (Pos mov) {  
		switch (mov) {
		case DERECHA:{
			if(this.getPos().getX() != Seccion.getLimiteIzquierdo()) {
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()][this.getPos().getY()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()+1][this.getPos().getY()];
				if(vSalida.puedoSalir(mov)){
					if(vEntrada.puedoEntrar(mov))
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		case IZQUIERDA:{
			if(this.getPos().getX() != Seccion.getLimiteDerecho()) {
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()][this.getPos().getY()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()-1][this.getPos().getY()];
				if(vSalida.puedoSalir(mov)){
					if(vEntrada.puedoEntrar(mov))
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		case ARRIBA:{
			if(this.getPos().getY() != Seccion.getLimiteSuperiorPB()) { 
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()][this.getPos().getY()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()][this.getPos().getY()+1];
				if(vSalida.puedoSalir(mov)){
					if(vEntrada.puedoEntrar(mov))
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		case ABAJO:{
			if(this.getPos().getY() != Seccion.getLimiteInferiorT()) { 
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()][this.getPos().getY()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getX()][this.getPos().getY()-1];
				if(vSalida.puedoSalir(mov)){
					if(vEntrada.puedoEntrar(mov))
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		default:
			return false;
		}
	}
	
	/**
	 * M�todo que lee el proximo movimiento (proxMov) ingresado y mueve a Felix si es posible
	 */
	public void mover () {
		this.setPos(new Posicion());
		Pos mov = this.getProxMov();
		if (mov != null) {
			switch (mov) {
			case DERECHA:
				if ((this.getPos().getX() < Seccion.getLimiteDerecho()) && this.puedeMoverse(mov)) {				
					this.getPos().calcularMovimiento(mov);
				}
				break;
			case IZQUIERDA:
				if ((this.getPos().getX() > Seccion.getLimiteIzquierdo()) && this.puedeMoverse(mov)) {				
					this.getPos().calcularMovimiento(mov);
				}
				break;
			case ARRIBA:
				if ((this.getPos().getY() < Ralph.getInstancia().getPos().getY()) && this.puedeMoverse(mov)) {
					this.getPos().calcularMovimiento(mov);
				}
				break;
			case ABAJO:
				if ((this.getPos().getY() > (Ralph.getInstancia().getPos().getY()) - 3) && this.puedeMoverse(mov)) {
					this.getPos().calcularMovimiento(mov);
				}
			}
			this.setProxMov(null);
		}
	}
	
	
	/**
	 * M�todo que pregunta si el resto de los individuos colisiona con Felix.
	 * En este caso retorna siempre false
	 * @param p
	 * @return boolean
	 */
	public boolean colision (Posicion p) { 
		return false;
	}
	
}
