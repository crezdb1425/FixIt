package game;


public class Pastel extends Individuo{
	private boolean aparecer;
	private int contador;
	private boolean comio;
	
	public Pastel() {
		this.aparecer = false;
		this.contador = 10;
		this.comio = false;
	}
	
	public boolean isAparecer() {
		return aparecer;
	}


	public void setAparecer(boolean aparecer) {
		this.aparecer = aparecer;
	}

	
	/**
	 * M�todo toString que devuelve "Pastel"
	 * @return String
	 */
	public String toString () {
		return "Pastel";
	}
	
	/**
	 * M�todo que si todavia Felix no lo comio y tiene tiempo visible, decrementa el contador hasta que llega a 0
	 * y entonces reinicia el contador y desaparece, al igual que cuando felix lo come
	 */
	public void mover () {
		if (comio) {
			aparecer=false;
			contador=10;
			comio=false;
		}
		else {
			if (contador != 0) {
				contador -=1;
			}
			else {
				if (aparecer) {
					aparecer = false;
					contador = 10;
				}
			}
		}
		
	}
	
	/**
	 * M�todo que verifica si su posicion coincide con la de Felix, y cambia comio a false
	 * @param p posicion de felix
	 */
	public boolean colision(Posicion p) {
		if (p.equals(this.getPos())) {
			this.comio=true;
			return true;
		}
		else {
			return false;
		}
	}

}
