package game;

import java.util.concurrent.CopyOnWriteArrayList;

public class Juego {
	private int nivelActual;
	private int puntaje;
	private Ranking cincoMejores[] = new Ranking[5];    
	private int tiempoTotal;          // para jugar 
	private int tiempo;				// transcurrido
	private Edificio edif;
	private boolean over;
	private CopyOnWriteArrayList<Individuo> individuos = new CopyOnWriteArrayList<Individuo>();

	private static Juego instancia = new Juego();


	public static Juego getInstancia() {
		return instancia;
	}
	
	/**
	 * Constructor de la clase Juego
	 * Inicializa las variables nivel actual(1), puntaje(0), reservar memoria para vector del Ranking, inicializar tiempo total(100), 
	 * inicializar variable over (false) que indica cuando se termina el juego 
	 */
	public Juego () {
		this.nivelActual=1;
		this.puntaje=0;
		for (int i=0; i<5; i++)
			this.cincoMejores[i]=new Ranking();		
		this.tiempoTotal=100;
		this.tiempo=0;
		this.over=false;
	};
	
	
	public int getNivelActual() {
		return nivelActual;
	}


	public void setNivelActual(int nivelActual) {
		this.nivelActual = nivelActual;
	}


	public int getPuntaje() {
		return puntaje;
	}


	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}


	public Ranking[] getCincoMejores() {
		return cincoMejores;
	}


	public void setCincoMejores(Ranking[] cincoMejores) {
		this.cincoMejores = cincoMejores;
	}


	public double getTiempoTotal() {
		return tiempoTotal;
	}


	public void setTiempoTotal(int tiempoTotal) {
		this.tiempoTotal = tiempoTotal;
	}


	public double getTiempo() {
		return tiempo;
	}


	public void setTiempo(int t) {
		this.tiempo = t;
	}


	public Edificio getEdif() {
		return edif;
	}


	public void setEdif(Edificio edif) {
		this.edif = edif;
	}

	
	public boolean isOver() {
		return over;
	}

	public void setOver(boolean over) {
		this.over = over;
	}


	/**
	 * M�todo que aumenta el tiempo transcurrido
	 */
	public void sumarTiempo () {  
		this.tiempo += 1;
	}
	
	/**
	 * M�todo que repara la ventana de la posicion pos
	 * @param pos posicion de la ventana a reparar
	 */
	public void repararVentana(Posicion pos) {
		Edificio.getInstancia().repararVentana(pos);
	}
	
	
	/**
	 * M�todo que incrementa el nivel actual, disminuye en un 10% el tiempo total para jugar y aumenta en un 10%: cantidad de ventanas abiertas, cantidad de maceteros,
	 * cantidad de molduras, cantidad de ventanas rotas y la cantidad de ladrillos que tiene Ralph.
	 */
	public void pasarNivel() {
		this.nivelActual++;
		this.tiempoTotal-=(this.tiempoTotal*0.1);
		Edificio.getInstancia().setVentanasAbiertas(Edificio.getInstancia().getVentanasAbiertas()+(int)(Edificio.getInstancia().getVentanasAbiertas()*0.1));
		Edificio.getInstancia().setCantMaceteros(Edificio.getInstancia().getCantMaceteros()+(int)(Edificio.getInstancia().getCantMaceteros()*0.1));
		Edificio.getInstancia().setCantMolduras(Edificio.getInstancia().getCantMolduras()+(int)(Edificio.getInstancia().getCantMolduras()*0.1));
		Edificio.getInstancia().setVentanasRotas(Edificio.getInstancia().getVentanasRotas()+(int)(Edificio.getInstancia().getVentanasRotas()*0.1));
		Ralph.getInstancia().setMaxLadrillos(Ralph.getInstancia().getMaxLadrillos()+(int)(Ralph.getInstancia().getMaxLadrillos()*0.1));
	}



	
	/**
	 * M�todo que se ejecuta al ganar el juego
	 */
	public void victoria () {
		System.out.println("Felicitaciones ganaste!! Ujuuuu");
		//Ranking.getInstancia().guardarPuntaje(puntaje);
	}
	
	/**
	 * M�todo que se ejecuta al perder el juego
	 */
	public void gameOver () {
		System.out.println("Buuuu Perdiste!!!");
		this.over = true;
		//Ranking.getInstancia().guardarPuntaje(this.puntaje);
	}


	/**
	 * M�todo que suma al puntaje actual una cantidad p de puntos
	 * @param p puntaje a sumar
	 */
	public void sumarPuntos(int p) {
		this.setPuntaje(this.getPuntaje() + p);
	}
	

	/**
	 * M�todo que inicializa todas las ventanas del edificio del nivel actual
	 */
	public void inicializarVentana() {
		Edificio.getInstancia().inicializarVentanas();
	}
	
	
	/**
	 * M�todo que reinicia la seccion actual, 
	 */
	public void reiniciarSeccion() {
		if(Edificio.getInstancia().getSeccionActual()==Seccion.PLANTABAJA)
			Edificio.getInstancia().setCantVentanasRotasActual((int)Edificio.getInstancia().getVentanasRotas());
		else
			if(this.edif.getSeccionActual()==Seccion.MEDIO)
				Edificio.getInstancia().setCantVentanasRotasActual((int)Edificio.getInstancia().getVentanasRotas()-(Edificio.getInstancia().getVentanasRotas()/3));
			else
				Edificio.getInstancia().setCantVentanasRotasActual((int)Edificio.getInstancia().getVentanasRotas()-(2*Edificio.getInstancia().getVentanasRotas()/3));
	}
	
	
	/**
	 * M�todo que pasa de seccion
	 */
	public void pasarSeccion () {
		if (Edificio.getInstancia().getSeccionActual() == Seccion.PLANTABAJA) {
			Edificio.getInstancia().setSeccionActual(Seccion.MEDIO);
		}
		else {
			Edificio.getInstancia().setSeccionActual(Seccion.TERRAZA);
		}
		Posicion pos = new Posicion();
		if (Edificio.getInstancia().getSeccionActual() == Seccion.MEDIO) {
			pos.setX(Ralph.getInstancia().getPos().getX() + 2);
		}
		else {
			pos.setX(Ralph.getInstancia().getPos().getX() + 3);
		}
		pos.setY(Ralph.getInstancia().getPos().getY());
		Ralph.getInstancia().setPos(pos);
		pos.setX(FelixJr.getInstancia().getPos().getX() + 3);
		pos.setY(FelixJr.getInstancia().getPos().getY());
		this.setPuntaje(this.getPuntaje() + 400);
	}



	/**
	 * M�todo que inicializa un nivel, poniendo la seccion actual en planta baja, posicionando a felix y ralph nuevamnte al inicio.
	 */
	public void inicializarNivel() {
		Posicion pos= new Posicion();
		pos.setX(0);
		pos.setY(0);
		Edificio.getInstancia().setSeccionActual(Seccion.PLANTABAJA);
		this.reiniciarSeccion();
		FelixJr.getInstancia().setPos(pos);
		pos.setY(3);
		Ralph.getInstancia().setPos(pos);
	}

	/**
	 * Metodo que invoca al metodo de edificio para inicializar maceteros y molduras
	 */
	public void inicializarObstaculos() {
		Edificio.getInstancia().inicializarMaceteroYMolduras();
	}
	
	
	
	/*//////////////////////////////////////// Se agrego /////////////////////////////////////// */	
	
	/**
	 * M�todo que reinicia la seccion al Felix chocar pajaro
	 */
	public void chocarPajaro() {
		this.reiniciarSeccion();
	}
	
	/**
	 * M�todo que corrobora si un pajaro, ladrillo o pastel coincide su posicion con la de Felix
	 */
	public void colision () {
		for (Individuo i : individuos) {
			boolean colision = i.colision(FelixJr.getInstancia().getPos());
			switch (i.toString()) {
			case "Pajaro":
				if (colision) 
					this.chocarPajaro();
				break;
			case "Ladrillo":
				if (colision)
					FelixJr.getInstancia().perderVida();
				break;
			case "Pastel":
				if (colision)
					FelixJr.getInstancia().comerPastel();
				break;
			}
		}
	}
	
	/**
	 * M�todo que se ejecuta en cada instante haciendo los chequeos correspondientes, como: si hubo colision, si se paso de nivel, si se perdio ya sea 
	 * por quedarse sin vidas o por terminarse el tiempo o si se gano
	 */
	public void actualizar () {
		for (Individuo i : individuos ) {
			i.mover();
		}
		this.colision();
		Ralph.getInstancia().actualizar();
		
		
		if (Edificio.getInstancia().getCantVentanasRotasActual() == 0) {  //this.edif.getVentanasRotas()
			this.pasarNivel();
			System.out.println("Has pasado de nivel!!");
		}
		
		if (FelixJr.getInstancia().getVidas() == 0) {
			this.gameOver();
			System.out.println("Te quedaste sin vidas!!");
		}
		if ((this.nivelActual == 10) && (Edificio.getInstancia().getCantVentanasRotasActual() == 0)) {
			this.victoria();
		}
		
		this.tiempo +=1;			// Estos dependen de cuanto es un segundo por ejecucion
		this.tiempoTotal -=1;		//
		
		if (tiempoTotal == 0) {
			this.gameOver();
			System.out.println("Se te termin� el tiempo!!");
		}
	}
	/* //////////////////////////////////////////////////////////////////////////////////////////////////////////////// */
	
	/**
	 * M�todo que se ejecuta antes que comience el juego. Crea las instancias de los individuos, asi como inicializa los tiempos, el puntaje, e inicializa 
	 * las ventanas y los obstaculos.
	 */
	public void comenzar () {
		this.individuos.add(Ralph.getInstancia());
		this.individuos.add(FelixJr.getInstancia());
		for (int i=2; i<5; i++) {
			this.individuos.add(new Pajaro());
			this.individuos.add(new Nicelander());
		}
		edif=Edificio.getInstancia();
		this.over = false;
		this.setTiempo(0);
		this.setTiempoTotal(90);					
		this.setPuntaje(0);
		this.setNivelActual(1);
		this.inicializarNivel();					
		this.inicializarVentana();					
		this.inicializarObstaculos();		
	}
}