package game;

public abstract class Individuo {
	private Posicion pos;
	private double velocidad;
	
	public Individuo () {
		Posicion posicion = new Posicion();
		this.pos = posicion;
	}
	
	public Posicion getPos() {
		return pos;
	}
	public void setPos(Posicion pos) {
		this.pos = pos;
	}
	public double getVelocidad() {
		return velocidad;
	}
	public void setVelocidad(double velocidad) {
		this.velocidad = velocidad;
	}
	
	
	public abstract void mover();
	
	public abstract boolean colision (Posicion p); 
	
}
