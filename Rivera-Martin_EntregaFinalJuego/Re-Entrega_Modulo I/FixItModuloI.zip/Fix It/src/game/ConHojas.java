package game;

import java.util.Random;

public class ConHojas extends Ventana{
	private boolean abierta;
	
	public boolean isAbierta() {
		return abierta;
	}



	public void setAbierta(boolean abierta) {
		this.abierta = abierta;
	}



	public ConHojas(Posicion pos) {
		super(pos);
		Panel [] panel = new Panel[2];
		for(int i=0; i<panel.length;i++) {
			panel[i]=new Panel();
			panel[i].setEstado(Estado.SANO);
		}
		this.setPaneles(panel);
	}

	
	
	/**
	 * M�todo que repara los paneles de la ventana si estan abiertas.
	 * Si el panel inferior(par) no est� sano, se llama al metodo reparar() de la superclase ventana
	 * Sino, se pregunta por el superior, si no esta sano, se sigue la misma logica que antes y ademas suma 100ptos y se resta la cantidad
	 * de ventanas rotas actual del edificio
	 */
	public void reparar () {
		if (abierta) {		
			if (this.getPaneles()[0].getEstado() != Estado.SANO) {
				this.reparar(0);
			}
			else {
				if (this.getPaneles()[1].getEstado() != Estado.SANO) {
					this.reparar(1);
						Juego.getInstancia().sumarPuntos(100);
						Juego.getInstancia().getEdif().setCantVentanasRotasActual(Juego.getInstancia().getEdif().getCantVentanasRotasActual() - 1);
					}
				}
			}
		}
	
	
	/**
	 * M�todo que devuelve un String = Hojas
	 * @return String
	 */
	public String toString() {
		return "Hojas";
	}

	/**
	 * M�todo que rompe los paneles de maneta aleatoria
	 */
	public void inicializarPaneles() {
		if(this.abierta) {
				Random r = new Random (System.currentTimeMillis());
				int cantP = r.nextInt(2)+1;
				int posPanel = r.nextInt(2);
				switch(cantP){
				case (1):{
					this.getPaneles()[posPanel].romperPanel();
				}
				case (2):{
					this.getPaneles()[0].romperPanel();
					this.getPaneles()[1].romperPanel();
				}
				}
			}
		}
	
	
	/**
	 * Metodo que devuelve true a Felix si es posible para el moverse en todas las direcciones
	 * dependiendo si hay moldura, macetero o las persianas estan abiertas
	 * @param dir direccion en la que se deberia mover felix
	 * @return boolean
	 */
	public boolean puedoSalir (Pos dir) {
		switch(dir) {
		case ARRIBA:{
			if(this.isMoldura())
				return false;
			else
				return true;
		}
		case ABAJO:{
			if(this.isMacetero())
				return false;
			else
				return true;
		}
		case IZQUIERDA:{
			if(this.isAbierta())
				return false;
			else
				return true;
		}
		case DERECHA:{
			return true;
		}
		default:
			return true;
		}
	}
	
	
	/**
	 * Metodo que devuelve true a Felix si es posible para el moverse en todas las direcciones
	 * dependiendo si hay moldura, macetero o las persianas estan abiertas
	 * @param dir direccion en la que se deberia mover felix
	 * @return boolean
	 */
	public boolean puedoEntrar (Pos dir) {
		switch(dir) {
		case ARRIBA:{
			if(this.isMacetero())
				return false;
			else
				return true;
		}
		case ABAJO:{
			if(this.isMoldura())
				return false;
			else
				return true;
		}
		case IZQUIERDA:{
			return true;
		}
		case DERECHA:{
			if(this.isAbierta())
				return false;
			else
				return true;
		}
		default: 
			return true;
		}
	}
	
}
