package game;

public class Panel {
	private Estado estado;
	private int cant_martillazos;
	
	
	public Estado getEstado() {
		return estado;
	}
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	public int getCant_martillazos() {
		return cant_martillazos;
	}
	public void setCant_martillazos(int cant_martillazos) {
		this.cant_martillazos = cant_martillazos;
	}
	
	/**
	 * M�todo que complementa al metodo inicializarVentana() de clase Ventana
	 */
	public void romperPanel(){
		if(Math.random()<0.5)
			this.estado = Estado.MEDIOROTO;
		else
			this.estado = Estado.ROTO;
	}

	
}
