package game;


public class Ladrillo extends Individuo{


	public String toString () {
		return "Ladrillo";
	}
	
	/**
	 * M�todo que mueve el ladrillo de manera vertical y hacia abajo, disminuyendo de a uno
	 */
	public void mover (){
		this.setPos(Ralph.getInstancia().getPos()); 
		for (int i = 1; i<3; i++){
			this.getPos().setY(this.getPos().getY()-1);
		}
	}
	
	/**
	 * M�todo que corrobora si su posicion coincide con la de Felix, en caso verdadero retorna true
	 * @param p posicion de fleix 
	 * @return boolean
	 */
	public boolean colision (Posicion p) {
		if (p.equals(this.getPos())) {
			return true;
		}
		else {
			return false;
		}
	}
	

}
