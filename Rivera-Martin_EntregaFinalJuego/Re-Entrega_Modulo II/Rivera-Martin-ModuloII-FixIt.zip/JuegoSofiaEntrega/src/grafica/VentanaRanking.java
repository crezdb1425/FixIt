package grafica;
import java.io.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.PublicKey;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import game.Ranking;

public class VentanaRanking{
	//private JTextArea text = new JTextArea();	
	private Ranking [] top = new Ranking[5];
	
	
	public VentanaRanking() {
		/*
		super("Ranking de los 5 mejores");
		this.setLayout(null);
		this.setSize(650, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //al hacer clic en cerrar termina programa
		this.setLocationRelativeTo(null);				//la ventana aparece centrada
		*/
	
		for (int i=0; i<5; i++) {
			top[i] = new Ranking();
		}
		
		this.cargarTop();
		
		String str = "";
		for (int i=0; i<5; i++) {
			str = str + "Puesto n�mero " + i + "---->  "+ top[i].getNombre() + " con el puntaje: " + top[i].getPuntos() + "\n\n"; 
		}
		
		
		//JTextArea text = new JTextArea(str);	
		
		JOptionPane.showMessageDialog(null,str);
		
		//text.setVisible(true);
		
		
		//this.setVisible(true);
		
	}
	
	
	public void cargarTop() {
		File file = new File ("cincomejores.txt");
		
		if (!file.exists()) {
			JOptionPane.showMessageDialog(null, "Opci�n no disponible en este momento");
		}
		else {
			FileReader reader = null;
			try {
				reader = new FileReader(file);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BufferedReader almacenamiento = new BufferedReader(reader); // para no hacer tantos accesos a disco
			String str = "";
			int puntaje;
			for (int i=0; i<5; i++) {
				try {
					str = almacenamiento.readLine();
				} catch (IOException e) {
					e.printStackTrace();    //que me almacene una linea de texto
				}		
				if(str != null) {
					if ((i%2) == 0) {    // si es una linea par es el nombre
						this.top[(i/2)+1].setNombre(str);
						
					}
					else {
						puntaje = Integer.parseInt(str); // convierto de string a entero
						this.top[i-1].setPuntos(puntaje);
					}

				}
				}
		}
	}
	
	public static void main(String[] args) {
		VentanaRanking ventanaRanking = new VentanaRanking();
	}
		
		
}
