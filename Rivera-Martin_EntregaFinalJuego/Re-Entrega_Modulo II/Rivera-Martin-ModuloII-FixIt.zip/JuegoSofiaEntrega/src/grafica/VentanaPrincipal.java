package grafica;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import controlador.Controlador;


public class VentanaPrincipal extends JFrame implements ActionListener{
	private JButton reglas = new JButton("REGLAS DEL JUEGO");
	private JButton jugar = new JButton("�QUIERO JUGAR!");
	private	JButton ranking = new JButton("TOP 5");
	private JButton configuracion = new JButton("CONFIGURACION");
	private int [] n= new int [1];
	
	
	
	public VentanaPrincipal() {
		super("Fix It Felix Jr.");
		this.setLayout(null);
		this.setSize(650, 200);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //al hacer clic en cerrar termina programa
		this.setLocationRelativeTo(null);				//la ventana aparece centrada
		this.getContentPane().setBackground(Color.CYAN);
		
		reglas.setBounds(10, 70, 200, 50);
		reglas.setBackground(Color.BLACK);
		reglas.setForeground(Color.WHITE);
		
		jugar.setBounds(220, 70, 200, 50);
		jugar.setBackground(Color.BLACK);
		jugar.setForeground(Color.WHITE);
		
		ranking.setBounds(430, 70, 200, 50);
		ranking.setBackground(Color.BLACK);
		ranking.setForeground(Color.WHITE);
		
		configuracion.setBounds(470, 20, 150, 30);
		configuracion.setBackground(Color.BLACK);
		configuracion.setForeground(Color.WHITE);
		configuracion.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Niveles(n);				
			}
		});
		
		reglas.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new VentanaReglas();
				
			}
		});
		jugar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Controlador(n[0]);
				
			}
		});
		
		ranking.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					new VentanaRanking();
				
			}
		});
	
		this.add(reglas);
		this.add(jugar);
		this.add(ranking);
		this.add(configuracion);
		this.setVisible(true);
		
	} 
	
		
	
	public static void main(String[] args) {
		VentanaPrincipal ventanaPrincipal = new VentanaPrincipal();
		
		
		
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}