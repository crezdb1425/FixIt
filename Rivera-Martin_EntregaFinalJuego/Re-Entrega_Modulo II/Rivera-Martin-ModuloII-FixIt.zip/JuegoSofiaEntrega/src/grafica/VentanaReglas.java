package grafica;


import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JFrame;


public class VentanaReglas extends JFrame{
	private String imgRegla = "img/reglas.png";
	private Image img;
	
	public VentanaReglas() {
		super("Instrucciones");
		URL imgURL = getClass().getClassLoader().getResource(imgRegla);
		if (imgURL == null) {
			System.err.println("No se encuentra el archivo:"+imgRegla);
		}else {
			try {
				img = ImageIO.read(imgURL);
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		this.setSize(874,640);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponents(g);
		g.drawImage(img,0,0,null);
	}
	

}
