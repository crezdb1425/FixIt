package grafica;



import javax.swing.*;

import controlador.MoverFelix;

import java.awt.*;


public class Jugando extends JFrame {
	private JPanel juegoJPanel;
	private JScrollPane scrollPane;

	
	public Jugando () {
		
		/// Configuracion de la ventana
		super("Fix It Felix Jr.");
		this.setSize(600, 830);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //al hacer clic en cerrar termina programa
		this.setLocationRelativeTo(null);
		////
		
		juegoJPanel = new PanelJuego();
		
		/*
		scrollPane = new JScrollPane();     ///
		scrollPane.setBounds(0, 0, 500, 715);   // posiciono el scroll dentro de la ventana
		scrollPane.setViewportView(juegoJPanel);  // agrego el panel que contiene el scroll
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);  // para que no se vea la barrita que corre el scroll
		Point p = new Point (0,715);
		scrollPane.getViewport().setViewPosition(p);
		
		
		*/
		
		
		//add(scrollPane);
	
		addKeyListener(new MoverFelix());
		add(juegoJPanel);
		
		//juegoJPanel.repaint();
		
		this.setVisible(true);
	}
	
	
	
	
	
	

}
