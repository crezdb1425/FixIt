package grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.*;

import game.Edificio;
import game.FelixJr;
import game.Individuo;
import game.Juego;
import game.Ladrillo;
import game.Ralph;
import game.Ventana;

public class PanelJuego extends JPanel{	
	Map<String, Image> img = new HashMap<String,Image>();

	
	public PanelJuego () {
		
		
		this.setBackground(Color.cyan); 					// Color de fondo del panel
		
		cargarMapa(img);

		setPreferredSize(new Dimension(500,1030));
	}
	

	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		
		// Dibujo el edificio
		g.drawImage(img.get("Edificio Completo"),145,0 , img.get("Edificio Completo").getWidth(null),img.get("Edificio Completo").getHeight(null), null);		
		
		int altoEdificio = 715;
		
		for (int i=0; i<9; i++) {
			for (int j=0; j<5; j++) {
				Ventana v = Edificio.getInstancia().getDimensionTotal()[i][j];
				Image image = img.get(v.toStringG());
				if (i==0 && j==2) {
					g.drawImage(image, image.getWidth(null)+103+j*53, 787-image.getHeight(null)-i*70,null);
				}
				else {
					if (i==1 && j==2){
						g.drawImage(image, image.getWidth(null)+103+j*53, 760-image.getHeight(null)-i*70, null);
						}
					else {
						g.drawImage(image, 175 +j*53 ,altoEdificio-conversorPosiciones(v.getPos().getX())-i*79, null);
						if (v.isMacetero()) {
							g.drawImage(img.get("Macetero"), 180 +j*53 ,altoEdificio-conversorPosiciones(v.getPos().getX())-i*79+40, null);
						}
						if (v.isMoldura()) {
							g.drawImage(img.get("Moldura"), 175 +j*53 ,altoEdificio-conversorPosiciones(v.getPos().getX())-i*79, null);
						}
					}
					
				}
			}
		}
		
		
		
		
		
		// Dibujo a felix
		g.drawImage(img.get(FelixJr.getInstancia().toString()), (FelixJr.getInstancia().getPos().getX()*53)+175, conversorPosiciones(FelixJr.getInstancia().getPos().getY())*79,null);
		
		
		// Dibujo a Ralph
		g.drawImage(img.get(Ralph.getInstancia().toString()), (Ralph.getInstancia().getPos().getX()*53) + 175, conversorPosiciones(Ralph.getInstancia().getPos().getY())*79, null);
		
		
	
		//Dibujar ldrillos
		for (Ladrillo l: Ralph.getInstancia().getLadri()) {
			if (l.isVisible()) {
				g.drawImage(img.get(l.toString()), l.getPos().getX()*53 + 180, conversorPosiciones(l.getPos().getY())*79 + 30, null);
			}
		}
		
		
		//Dibujar nicelander y pajaros	
		for (int i=2; i<6; i++) {
			Individuo individuo = Juego.getInstancia().getIndividuos().get(i);
			if (individuo.isVisible()) {
				g.drawImage(img.get(individuo.toStringG()), individuo.getPos().getX()*53 + 180, conversorPosiciones(individuo.getPos().getY())*80, null);
			}
		}
	
	}

	
	

	
	
	
	
	public Image cargarURLImage (String dir) {
		URL imgURL = getClass().getClassLoader().getResource(dir);
		if (imgURL == null) {
			System.err.println("No se encuentra el archivo:"+dir);
		}else {
			try {
				Image i = ImageIO.read(imgURL);
				return i;
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return null;
	}
	
	
	public void cargarMapa (Map<String, Image> imagenes) {
		imagenes.put("Edificio Completo", cargarURLImage("img/edificio/edificio_150.png"));		
		
		imagenes.put("Semi PB 0 0 0 0", cargarURLImage("img/SemiCircularPB/PB 0000.png"));
		imagenes.put("Semi PB 0 0 0 1", cargarURLImage("img/SemiCircularPB/PB 0001.png"));
		imagenes.put("Semi PB 0 0 1 0", cargarURLImage("img/SemiCircularPB/PB 0010.png"));
		imagenes.put("Semi PB 0 0 1 1", cargarURLImage("img/SemiCircularPB/PB 0011.png"));
		imagenes.put("Semi PB 0 1 0 0", cargarURLImage("img/SemiCircularPB/PB 0100.png"));
		imagenes.put("Semi PB 0 1 0 1", cargarURLImage("img/SemiCircularPB/PB 0101.png"));
		imagenes.put("Semi PB 0 1 1 0", cargarURLImage("img/SemiCircularPB/PB 0110.png"));
		imagenes.put("Semi PB 0 1 1 1", cargarURLImage("img/SemiCircularPB/PB 0111.png"));
		imagenes.put("Semi PB 1 0 0 0", cargarURLImage("img/SemiCircularPB/PB 1000.png"));
		imagenes.put("Semi PB 1 0 0 1", cargarURLImage("img/SemiCircularPB/PB 1001.png"));
		imagenes.put("Semi PB 1 0 1 0", cargarURLImage("img/SemiCircularPB/PB 1010.png"));
		imagenes.put("Semi PB 1 0 1 1", cargarURLImage("img/SemiCircularPB/PB 1011.png"));
		imagenes.put("Semi PB 1 1 0 0", cargarURLImage("img/SemiCircularPB/PB 1100.png"));
		imagenes.put("Semi PB 1 1 0 1", cargarURLImage("img/SemiCircularPB/PB 1101.png"));
		imagenes.put("Semi PB 1 1 1 0", cargarURLImage("img/SemiCircularPB/PB 1110.png"));
		imagenes.put("Semi PB 1 1 1 1", cargarURLImage("img/SemiCircularPB/PB 1111.png"));
		
		imagenes.put("Semi 0 0 0 0 0 0 0 0", cargarURLImage("img/SemiCircular/0000 - 0000.png"));
		imagenes.put("Semi 0 0 0 1 0 0 0 0", cargarURLImage("img/SemiCircular/0001 - 0000.png"));
		imagenes.put("Semi 0 0 1 0 0 0 0 0", cargarURLImage("img/SemiCircular/0010 - 0000.png"));
		imagenes.put("Semi 0 0 1 1 0 0 0 0", cargarURLImage("img/SemiCircular/0011 - 0000.png"));
		imagenes.put("Semi 0 1 0 0 0 0 0 0", cargarURLImage("img/SemiCircular/0100 - 0000.png"));
		imagenes.put("Semi 0 1 0 1 0 0 0 0", cargarURLImage("img/SemiCircular/0101 - 0000.png"));
		imagenes.put("Semi 0 1 1 0 0 0 0 0", cargarURLImage("img/SemiCircular/0110 - 0000.png"));
		imagenes.put("Semi 0 1 1 1 0 0 0 0", cargarURLImage("img/SemiCircular/0111 - 0000.png"));
		imagenes.put("Semi 1 0 0 0 0 0 0 0", cargarURLImage("img/SemiCircular/1000 - 0000.png"));
		imagenes.put("Semi 1 0 0 1 0 0 0 0", cargarURLImage("img/SemiCircular/1001 - 0000.png"));
		imagenes.put("Semi 1 0 1 0 0 0 0 0", cargarURLImage("img/SemiCircular/1010 - 0000.png"));
		imagenes.put("Semi 1 0 1 1 0 0 0 0", cargarURLImage("img/SemiCircular/1011 - 0000.png"));
		imagenes.put("Semi 1 1 0 0 0 0 0 0", cargarURLImage("img/SemiCircular/1100 - 0000.png"));
		imagenes.put("Semi 1 1 0 1 0 0 0 0", cargarURLImage("img/SemiCircular/1101 - 0000.png"));
		imagenes.put("Semi 1 1 1 0 0 0 0 0", cargarURLImage("img/SemiCircular/1110 - 0000.png"));
		imagenes.put("Semi 1 1 1 1 0 0 0 0", cargarURLImage("img/SemiCircular/1111 - 0000.png"));
		
		imagenes.put("Comun 0 0", cargarURLImage("img/Comunes/C 00.png"));
		imagenes.put("Comun 0 1", cargarURLImage("img/Comunes/C 01.png"));
		imagenes.put("Comun 1 0", cargarURLImage("img/Comunes/C 10.png"));
		imagenes.put("Comun 1 1", cargarURLImage("img/Comunes/C 11.png"));
		imagenes.put("Comun 1 2", cargarURLImage("img/Comunes/C 12.png"));
		imagenes.put("Comun 2 1", cargarURLImage("img/Comunes/C 21.png"));
		imagenes.put("Comun 0 2", cargarURLImage("img/Comunes/C 02.png"));
		imagenes.put("Comun 2 0", cargarURLImage("img/Comunes/C 20.png"));
		imagenes.put("Comun 2 2", cargarURLImage("img/Comunes/C 22.png"));
		
		imagenes.put("Hojas A 0 0", cargarURLImage("img/ConHojas/CH A 00.png"));
		imagenes.put("Hojas A 0 1", cargarURLImage("img/ConHojas/CH A 01.png"));
		imagenes.put("Hojas A 1 0", cargarURLImage("img/ConHojas/CH A 10.png"));
		imagenes.put("Hojas A 1 1", cargarURLImage("img/ConHojas/CH A 11.png"));
		imagenes.put("Hojas A 1 2", cargarURLImage("img/ConHojas/CH A 12.png"));
		imagenes.put("Hojas A 2 1", cargarURLImage("img/ConHojas/CH A 21.png"));
		imagenes.put("Hojas A 0 2", cargarURLImage("img/ConHojas/CH A 02.png"));
		imagenes.put("Hojas A 2 0", cargarURLImage("img/ConHojas/CH A 20.png"));
		imagenes.put("Hojas A 2 2", cargarURLImage("img/ConHojas/CH A 22.png"));
		imagenes.put("Hojas C 0 0", cargarURLImage("img/ConHojas/CH C 00.png"));
		
		imagenes.put("Nicelander", cargarURLImage("img/nicelander/slice237_@.png"));
		imagenes.put("Pastel", cargarURLImage("img/pastel/slice12_12.png"));
		
		imagenes.put("Macetero", cargarURLImage("img/obstaculos/macetero.png"));
		imagenes.put("Moldura", cargarURLImage("img/obstaculos/slice22_22.png"));
		
		imagenes.put("Ralph ", cargarURLImage("img/ralph/slice146_@.png"));
		imagenes.put("Ralph Tirar 1", cargarURLImage("img/ralph/slice150_@.png"));
		imagenes.put("Ralph Tirar 2", cargarURLImage("img/ralph/slice151_@.png"));
		imagenes.put("Ralph Tirar 3", cargarURLImage("img/ralph/slice163_@.png"));
		imagenes.put("Ralph Tirar 4", cargarURLImage("img/ralph/slice164_@.png"));
		imagenes.put("Ralph Tirar 5", cargarURLImage("img/ralph/slice165_@.png"));
		imagenes.put("Ralph Tirar 6", cargarURLImage("img/ralph/slice166_@.png"));
		
		imagenes.put("Ladrillo", cargarURLImage("img/rocas/slice10_10.png"));

		imagenes.put("FelixJr ", cargarURLImage("img/felix/slice65_65.png"));
		imagenes.put("FelixJr Chocar Pajaro", cargarURLImage("img/felix/slice292_@.png"));
		imagenes.put("FelixJr Izquierda", cargarURLImage("img/felix/slice103_@.png"));
		imagenes.put("FelixJr Derecha", cargarURLImage("img/felix/slice67_67.png"));
		imagenes.put("FelixJr Pastel 4 Izquierda", cargarURLImage("img/felix/slice118_@.png"));
		imagenes.put("FelixJr Pastel 3 Izquierda", cargarURLImage("img/felix/slice120_@.png"));
		imagenes.put("FelixJr Pastel 2 Izquierda", cargarURLImage("img/felix/slice125_@.png"));
		imagenes.put("FelixJr Pastel 1 Izquierda", cargarURLImage("img/felix/slice126_@.png"));
		imagenes.put("FelixJr Martillar 2 Izquierda", cargarURLImage("img/felix/slice136_@.png"));
		imagenes.put("FelixJr Martillar 1 Izquierda", cargarURLImage("img/felix/slice111_@.png"));
		imagenes.put("FelixJr Comer Pastel 4 Derecha", cargarURLImage("img/felix/slice91_91.png"));
		imagenes.put("FelixJr Comer Pastel 3 Derecha", cargarURLImage("img/felix/slice95_95.png"));
		imagenes.put("FelixJr Comer Pastel 2 Derecha", cargarURLImage("img/felix/slice69_69.png"));
		imagenes.put("FelixJr Comer Pastel 1 Derecha", cargarURLImage("img/felix/slice68_68.png"));
		imagenes.put("FelixJr Martillar 2 Derecha", cargarURLImage("img/felix/slice88_88.png"));
		imagenes.put("FelixJr Martillar 1 Derecha", cargarURLImage("img/felix/slice84_84.png"));
		
		imagenes.put("Pajaro Derecha 1", cargarURLImage("img/pajaro/slice09_09.png"));
		imagenes.put("Pajaro Derecha 0", cargarURLImage("img/pajaro/slice08_08.png"));
		imagenes.put("Pajaro Izquierda 1", cargarURLImage("img/pajaro/slice61_61.png"));
		imagenes.put("Pajaro Izquierda 0", cargarURLImage("img/pajaro/slice41_41.png"));

		imagenes.put("Ladrillo", cargarURLImage("img/rocas/slice10_10.png"));
	}
	
	
	
	public int conversorPosiciones (int posY) {
		return 9 - posY;
	}

	
	
	
}
