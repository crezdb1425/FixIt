package grafica;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;

public class Niveles extends JFrame{
	private JComboBox config = new JComboBox();
	
	public Niveles(final int [] n) {
		//config.setBounds(50, 2, 9, 3);
		config.setModel(new DefaultComboBoxModel(new String[] {"Nivel 1", "Nivel 2", "Nivel 3", "Nivel 4", "Nivel 5", "Nivel 6", "Nivel 7", "Nivel 8", "Nivel 9", "Nivel 10"}));
		config.setMaximumRowCount(10);
		
		config.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e)  {
				switch(config.getModel().getSelectedItem().toString()) {
				case "Nivel 1":
					n[0]=1;
					break;
				case "Nivel 2":
					n[0]=2;
					break;
				case "Nivel 3":
					n[0]=3;
					break;
				case "Nivel 4":
					n[0]=4;
					break;
				case "Nivel 5":
					n[0]=5;
					break;
				case "Nivel 6":
					n[0]=6;
					break;
				case "Nivel 7":
					n[0]=7;
					break;
				case "Nivel 8":
					n[0]=8;
					break;
				case "Nivel 9":
					n[0]=9;
					break;
				case "Nivel 10":
					n[0]=10;
				}
			}
		});
		this.add(config);
		this.setSize(50,100);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	
}
