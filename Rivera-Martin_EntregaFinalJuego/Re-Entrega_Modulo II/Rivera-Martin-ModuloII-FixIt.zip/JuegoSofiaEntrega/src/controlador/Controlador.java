package controlador;

import java.util.Timer;
import java.util.TimerTask;

import game.*;
import grafica.Jugando;

public class Controlador {


	public Controlador(int nivel) {
		final Jugando juego = new Jugando();
		final Juego j = Juego.getInstancia(); 
		j.comenzar(nivel);
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			
			@Override
			public void run() {
				if (!j.isOver()) {
					j.actualizar();
					juego.repaint();
				}
			}
		};
		
		timer.schedule(task,10,400);
		}
	
}

