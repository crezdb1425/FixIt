package controlador;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import game.FelixJr;
import game.Pos;

public class MoverFelix implements KeyListener{
	
    public MoverFelix() {
        }
	
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
        case KeyEvent.VK_UP:
        	FelixJr.getInstancia().setProxMov(Pos.ARRIBA);
            break;
        case KeyEvent.VK_DOWN:
        	FelixJr.getInstancia().setProxMov(Pos.ABAJO);
            break;
        case KeyEvent.VK_RIGHT:
        	FelixJr.getInstancia().setProxMov(Pos.DERECHA);
            break;
        case KeyEvent.VK_LEFT:
        	FelixJr.getInstancia().setProxMov(Pos.IZQUIERDA);
        	break;
        case KeyEvent.VK_SPACE:
        	FelixJr.getInstancia().repararVentana();
        	//break;
    }
		}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
