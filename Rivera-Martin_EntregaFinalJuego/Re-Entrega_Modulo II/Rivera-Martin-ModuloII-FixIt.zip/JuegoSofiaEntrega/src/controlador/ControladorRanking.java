package controlador;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import javax.swing.JOptionPane;

import game.Juego;
import game.Ranking;

public class ControladorRanking{
	private static ArrayList<Ranking> top = new ArrayList<>();
	
	public static ArrayList<Ranking> getTop() {
		return top;
	}
	
	
		public static void setTop(ArrayList<Ranking> top) {
		ControladorRanking.top = top;
	}



		public ControladorRanking() {
			
			File file = new File ("cincomejores.txt");
			
			
			if (!file.exists()) {
				try {
					file.createNewFile();
					try {
						FileOutputStream fileOut = new FileOutputStream(file);
						ObjectOutputStream escribir = new ObjectOutputStream(fileOut);					
						
						for (int i=0; i<5; i++) {
							Ranking r = new Ranking();
							r.setNombre("-------------------");
							r.setPuntos(0);
							ControladorRanking.getTop().add(r);
						}
						escribir.writeObject(ControladorRanking.getTop());
						escribir.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				} catch (IOException ex) {
					ex.printStackTrace();
				}
				
				
			}else {
				FileInputStream fileIn = null;
				try {
					fileIn = new FileInputStream(file);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				ObjectInputStream leer = null;
				try {
					leer = new ObjectInputStream(fileIn);
					ArrayList<Ranking> lista = (ArrayList<Ranking>) leer.readObject();
					ControladorRanking.setTop(lista);
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				calcularPuntaje();
				
				try {
					FileOutputStream fileOut = new FileOutputStream(file);
					ObjectOutputStream escribir = new ObjectOutputStream(fileOut);
					escribir.writeObject(ControladorRanking.getTop());
					escribir.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		}
		
		
		public static void calcularPuntaje () {
			int p = Juego.getInstancia().getPuntaje();
			Ranking ultimo = new Ranking();
			ultimo = ControladorRanking.getTop().get(0);
			Ranking jugador = new Ranking();
			jugador.setPuntos(p);
			int compare = ultimo.compareTo(jugador);
			
			if (compare <= 0) {
				//Ranking jugador = new Ranking();
				//jugador.setPuntos(p);
				jugador.setNombre(JOptionPane.showInputDialog(null, "Ingresa tu nombre: "));
				//ControladorRanking.getTop().add(jugador);
			if (compare == 0) {
				ControladorRanking.getTop().remove(4);
			} 
			ControladorRanking.getTop().add(jugador);
			if (ControladorRanking.getTop().size() == 6) {
				ControladorRanking.getTop().remove(5);
			}
			}
			
			Collections.sort(ControladorRanking.getTop());
			
		}
		
		
			
}