package game;

import java.util.Random;

public class SemiCircular extends Ventana{

	/**
	 * Constructor que inicializa en false los maceteros y molduras, carga la posicion de la ventana
	 * Reserva memoria para 8 paneles
	 * @param pos posicion de la ventana
	 */
	public SemiCircular(int x, int y) {
		this.setAbierta(true);
		this.setEstaRota(false);
		this.setMacetero(false);
		this.setMoldura(false);
		this.getPos().setX(x);
		this.getPos().setY(y);
		this.setPaneles(new Panel[8]);
		for(int i=0; i<this.getPaneles().length;i++) {
			this.getPaneles()[i]=new Panel();
			this.getPaneles()[i].setEstado(Estado.SANO);
		}
	}

	

	/**
	 * M�todo que repara los paneles a partir de los inferiores mas a la izquierda a los 
	 * superiores mas a la derecha
	 */
	public void reparar () {
		if (this.getPaneles()[0].getEstado() != Estado.SANO) {
			this.reparar(0);
		}
		else {
			if (this.getPaneles()[2].getEstado() != Estado.SANO) {
				this.reparar(2);
			}
			else {
				if (this.getPaneles()[4].getEstado() != Estado.SANO) {
					this.reparar(4);
				}
				else {
					if (this.getPaneles()[6].getEstado() != Estado.SANO) {
						this.reparar(6);
					 }
					else {
						if (this.getPaneles()[1].getEstado() != Estado.SANO) {
							this.reparar(1);
						}
						else {
							if (this.getPaneles()[3].getEstado() != Estado.SANO) {
								this.reparar(3);
							}
							else {
								if (this.getPaneles()[5].getEstado() != Estado.SANO) {
									this.getPaneles()[5].setCant_martillazos(this.getPaneles()[5].getCant_martillazos() + 1);
									if (this.getPaneles()[5].getCant_martillazos() == 2) {
										this.getPaneles()[5].setEstado(Estado.SANO);
									}
								}
							}
						}
					}
				}
			}
		}
		int cantPaneles = 0;
		for (int i=0; i<this.getPaneles().length; i++) {
			if (!this.getPaneles()[i].getEstado().equals(Estado.SANO)) {
				cantPaneles++;
			}
		}
		if (cantPaneles == 0 && this.isEstaRota()) {
			Edificio.getInstancia().getSeccionActual().setCantVentanasRotas(Edificio.getInstancia().getSeccionActual().getCantVentanasRotas()-1);
			this.setEstaRota(false);
			Juego.getInstancia().sumarPuntos(100);
		}
	}
	
	
	public String toString() {
		return "Semi";
	}

	
	public String [] consultarEstadoPaneles() {
		String [] paneles =new String[this.getPaneles().length];
		for (int i=0; i<this.getPaneles().length;i++) {
			switch(this.getPaneles()[i].getEstado()){
			case SANO:
				paneles[i]="0";
				break;
			default:
				paneles[i]="1";
			}
		}
		return paneles;
	}
	
	
	public String toStringG() {
		String [] paneles = this.consultarEstadoPaneles();
		return this.toString() + " " + paneles[0] + " " + paneles[1] + " " + paneles[2] + " " + paneles[3] + " " + paneles[4] + " " + paneles[5] + " " + paneles[6] + " " + paneles[7];
	}
	
	/**
	 * M�todo que rompe la cantidad de paneles de manera aleatoria
	 */
	public void inicializarPaneles() {
		Random r =new Random(System.currentTimeMillis());
		int cantP = r.nextInt(3)+1;
		while(cantP>0) {
			for(int i=0; i<4;i++) {
				if(this.getPaneles()[i].getEstado()==Estado.SANO)
					if(Math.random()<0.5) {
						this.getPaneles()[i].romperPanel();
						cantP--;
					}		
			}
		}
	}





	@Override
	public boolean puedoSalir(Pos dir) {
		// TODO Auto-generated method stub
		return true;
	}





	@Override
	public boolean puedoEntrar(Pos dir) {
		// TODO Auto-generated method stub
		return true;
	}


		
}
