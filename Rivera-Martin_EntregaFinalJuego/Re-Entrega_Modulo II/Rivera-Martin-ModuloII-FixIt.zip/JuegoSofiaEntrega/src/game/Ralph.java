package game;

public class Ralph extends Individuo{
	private int maxLadrillos;  
	private Ladrillo [] ladri;									
	private int cantLadrillos;			/* ladrillos que le quedan (maxLadrillos - los que vaya usando) */
	private int contadorTirarLadrillo;										
	private int contadorMover;					///nuevo
	private String grafica;
	
	private static Ralph instanncia = new Ralph();				
	
	public static Ralph getInstancia() {						
		return instanncia;
	}
	
	
	public Ralph () {
		this.maxLadrillos=40;
		this.cantLadrillos=39;						// porque el indice llega hasta 39
		this.contadorTirarLadrillo=0;
		this.contadorMover=0;								/// nuevo
		this.grafica="";
		this.ladri = new Ladrillo[maxLadrillos];
		for (int i = 0; i < ladri.length; i++) {
			ladri[i] = new Ladrillo();
		}
	}
	
	
	public int getCantLadrillos() {
		return cantLadrillos;
	}
	public void setCantLadrillos(int cantLadrillos) {
		this.cantLadrillos = cantLadrillos;
	}
	
	public int getMaxLadrillos() {
		return maxLadrillos;
	}
	public void setMaxLadrillos(int maxLadrillos) {
		this.maxLadrillos = maxLadrillos;
	}
	
	
	public Ladrillo[] getLadri() {
		return ladri;
	}


	public void setLadri(Ladrillo[] ladri) {
		this.ladri = ladri;
	}


	/**
	 * M�todo que mueve a Ralph aleatoriamente de izquierda a derecha
	 */
	public void mover (){
		if (contadorMover == 20) {					// cada 10 segundos se mueve (10*2)
			this.contadorMover=0;
			double ran = Math.random();
			if(ran < 0.5){
				if(this.getPos().getX()==Seccion.getLimiteIzquierdo()){
					this.getPos().calcularMovimiento(Pos.DERECHA);
					this.getPos().calcularMovimiento(Pos.DERECHA);
				}
				else
					this.getPos().calcularMovimiento(Pos.IZQUIERDA);
				}
				else {
					if (this.getPos().getX()==Seccion.getLimiteDerecho()){
						this.getPos().calcularMovimiento(Pos.IZQUIERDA);
						this.getPos().calcularMovimiento(Pos.IZQUIERDA);
					}
					else
						this.getPos().calcularMovimiento(Pos.DERECHA);
				}
		}
	}
	
	
	/**
	 * M�todo que incrementa el contador y cuando este llega a 10 (cada 5segundos), se reinicia en 0 y Ralph tira 3 ladrillos
	 */
	public void actualizar () {
		this.contadorMover++;
		contadorTirarLadrillo += 1;
		if (cantLadrillos > 0) {
			System.out.println("Entraa");
			System.out.println(contadorTirarLadrillo);
			switch (this.contadorTirarLadrillo){
				case 10:{
					this.tirarLadrillo();
					this.grafica= "Tirar 6";
					this.contadorTirarLadrillo = 0;
					break;}
				case 9:{
					this.grafica = "Tirar 5";
					break;}
				case 8:{
					this.tirarLadrillo();
					this.grafica= "Tirar 4";
					break;}
				case 7:{
					this.grafica= "Tirar 5";
					break;}
				case 6:{
					this.tirarLadrillo();
					System.out.println("tiraaaaaaaaaaaaaaaa");
					this.grafica = "Tirar 3";
					break;}
				case 5:
					this.grafica = "Tirar 2";
				case 4:
					this.grafica = "Tirar 1";
				case 0:
					//this.contadorTirarLadrillo = 10;
				default:
					this.grafica="";
			}
				if (this.contadorTirarLadrillo < 4) {
					this.grafica = "";
				}
		}
		for (Ladrillo l: this.ladri) {
			l.mover();
		}
	}

	/**
	 * M�todo que verifica la colision entre Felix y el resto de los individuos pero en este caso no es aplicable,
	 * retorna false siempre
	 * @param p posicion de felix
	 * @return boolean
	 */
	public boolean colision(Posicion p) {
		return false;
	}
	
	public void pasarNivel() {
		this.setMaxLadrillos(this.getMaxLadrillos()+((int)(this.getMaxLadrillos()*0.1)));
		this.ladri[cantLadrillos].setVisible(false);
		this.getPos().setY(3);
		this.getPos().setX(2);
	}

	/**
	 * M�todo que complementa al metodo actualizar() y decrementa la cantidad de ladrillos actual e indica a ladrillos que caigan
	 */
	public void tirarLadrillo(){
		this.cantLadrillos--;
		this.ladri[cantLadrillos].setVisible(true);
		this.ladri[cantLadrillos].mover();
	}

	public String toString () {
		return "Ralph " + this.grafica;
	}

}
