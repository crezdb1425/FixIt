package game;

import java.io.Serializable;

public class Ranking implements Comparable<Ranking>, Serializable{
	private int puntos;
	private String nombre;
	
	
	public int getPuntos() {
		return puntos;
	}
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	private static Ranking instancia;
	
	public static Ranking getInstancia() {
		return instancia;
	}
	
	
	public Ranking() {
		this.puntos=0;
	}
	
	@Override
	public int compareTo(Ranking r) {
		return this.puntos - r.getPuntos();
	}

}
