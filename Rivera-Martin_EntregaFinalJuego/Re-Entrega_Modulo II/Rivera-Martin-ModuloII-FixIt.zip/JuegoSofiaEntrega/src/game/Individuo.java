package game;

public abstract class Individuo {
	private Posicion pos=new Posicion();
	private double velocidad;
	private boolean visible;
	
	public Individuo () {
		this.visible = true;
	}
	
	public Posicion getPos() {
		return pos;
	}
	public void setPos(Posicion pos) {
		this.pos = pos;
	}
	public double getVelocidad() {
		return velocidad;
	}
	public void setVelocidad(double velocidad) {
		this.velocidad = velocidad;
	}
	
	
	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public void actualizar() {
		
	}
	
	public abstract void mover();
	
	public abstract boolean colision (Posicion p); 

	public Object toStringG() {
		return null;
	}

	
	
}
