package game;


public class FelixJr extends Individuo{
	private static final int VIDAS_INICIALES = 3;
	private static final int SEGUNDOS_INMUNIDAD = 5;
	private int vidas;
	private boolean inmunidad;
	private Pos proxMov;									
	private int inmuni;
	private String graficaNdo;
	private String grafica; /// nuevo
	private String graficaMover;
	private int contador;
	
	
	
	private static FelixJr instancia = new FelixJr();				
	
	private FelixJr () {
		this.contador = 0;
		this.vidas = VIDAS_INICIALES;
		this.grafica = "";           // el que devuelve el tostring
		this.graficaNdo = "";		// cual de varios dibujitos
		this.graficaMover = ""; 	// cual fue el movimiento anterior
	}
	
	public static FelixJr getInstancia() {						 	
		return instancia;	
	}

	
	public int getInmuni() {
		return inmuni;
	}
	public void setInmuni(int inmuni) {
		this.inmuni = inmuni;
	}
	public int getVidas() {
		return vidas;
	}
	public void setVidas(int vidas) {
		this.vidas = vidas;
	}
	
	public Pos getProxMov() {
		return proxMov;
	}

	public void setProxMov(Pos proxMov) {
		this.proxMov = proxMov;
	}
	
	public boolean isInmunidad() {
		return inmunidad;
	}
	public void setInmunidad(boolean inmunidad) {
		this.inmunidad = inmunidad;
	}
	
	
	public String getGrafica() {
		return grafica;
	}

	public void setGrafica(String grafica) {
		this.grafica = grafica;
	}

	public void repararVentana() {
		if (contador == 0) {
			this.graficaNdo = "Martillar";
			this.contador = 2;
		}
		Juego.getInstancia().repararVentana(this.getPos());
	}


	
public void pasarNivel() {
		this.getPos().setX(0);
		this.getPos().setY(0);
	}





	
	/**
	 * M�todo que decrementa vida a Felix y si estas llegan a 0, el juego termina, sino se reinicia el nivel
	 */
	public void perderVida () {
		this.vidas -= 1;
		if (this.vidas == 0) {
			Juego.getInstancia().gameOver();
		}
		else 
			Juego.getInstancia().reiniciarNivel();
		System.out.println("Perdiste una vida, te quedan "+this.vidas);
	}
	
	/**
	 * M�todo que le da inmunidad a felix, inicializa el contador inmuni
	 */
	public void comerPastel() {
		this.inmunidad = true;
		this.inmuni = SEGUNDOS_INMUNIDAD;
		this.graficaNdo = "Comer Pastel";
		this.contador = 4;
	}
		

	/**
	 * M�todo que verifica que Felix pueda moverse segun si hay macetero, moldura (en el caso de ventana comun)
	 * O si ademas tiene hojas (en el caso de ventana con hojas)
	 * @param mov movimiento que se le pide a felix
	 * @return boolean true, si es posible moverse, false caso contrario
	 */
	public boolean puedeMoverse (Pos mov) {  
		switch (mov) {
		case DERECHA:{
			if(this.getPos().getX() < Seccion.getLimiteDerecho()) {
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()][this.getPos().getX()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()][this.getPos().getX()+1];
				if(vSalida.puedoSalir(mov)&&vEntrada.puedoEntrar(mov)) {
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		case IZQUIERDA:{
			if(this.getPos().getX() > Seccion.getLimiteIzquierdo()) {
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()][this.getPos().getX()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()][this.getPos().getX()-1];
				if(vSalida.puedoSalir(mov)&&vEntrada.puedoEntrar(mov)){
					
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		case ARRIBA:{
			if(this.getPos().getY() < Seccion.TERRAZA.getLimiteSuperior()) { 
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()][this.getPos().getX()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()+1][this.getPos().getX()];
				if(vSalida.puedoSalir(mov)&&vEntrada.puedoEntrar(mov)){
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		case ABAJO:{
			if(this.getPos().getY() > Seccion.PLANTABAJA.getLimiteInferior()) { 
				Ventana vSalida = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()][this.getPos().getX()];
				Ventana vEntrada = Edificio.getInstancia().getDimensionTotal()[this.getPos().getY()-1][this.getPos().getX()];
				if(vSalida.puedoSalir(mov)&&vEntrada.puedoEntrar(mov)){
					return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		default:
			return false;
		}
	}
	
	
	public void actualizar() {
		if (this.contador != 0) {
			
			switch (this.graficaNdo) {
			case "Comer Pastel":
				this.grafica = this.graficaNdo+ " "+ this.contador + " " + this.graficaMover;
				break;
			case "Martillar":
					this.grafica = this.graficaNdo+ " " + this.contador + " " + this.graficaMover;
					break;
			case "Caer":
				if (contador%2 == 0) {
					this.grafica = "Caer 1";
				}
				else {
					this.grafica = "Caer 2";
				}
			}
			this.contador--;
		}
		if (this.inmuni != 0) {
			this.inmuni-=1;
		}
		else {
			this.inmunidad = false;
		}
		
	}
	
	
	
	    
	
	
	/**
	 * M�todo que lee el proximo movimiento (proxMov) ingresado y mueve a Felix si es posible
	 */
	public void mover () {
		if (this.getProxMov() != null && this.contador==0) {
			switch (this.getProxMov()) {
			case DERECHA:
				if ((this.getPos().getX() < Seccion.getLimiteDerecho()) && this.puedeMoverse(this.getProxMov())) {
					this.grafica = "Derecha";
					this.graficaMover = this.grafica;
					this.getPos().calcularMovimiento(this.getProxMov());
				}
				break;
			case IZQUIERDA:
				if ((this.getPos().getX() > Seccion.getLimiteIzquierdo()) && this.puedeMoverse(this.getProxMov())) {				
					this.getPos().calcularMovimiento(this.getProxMov());
					this.grafica = "Izquierda";
					this.graficaMover = this.grafica;
				}
				break;
			case ARRIBA:
				if ((this.getPos().getY() < Ralph.getInstancia().getPos().getY()-1) && this.puedeMoverse(this.getProxMov())) {		// le agregue el -1
					this.getPos().calcularMovimiento(this.getProxMov());
				}
				break;
			case ABAJO:
				if ((this.getPos().getY() > (Ralph.getInstancia().getPos().getY()) - 3) && this.puedeMoverse(this.getProxMov())) {
					this.getPos().calcularMovimiento(this.getProxMov());
				}
			}
			this.setProxMov(null);
		}
	}
	
	
	/**
	 * M�todo que pregunta si el resto de los individuos colisiona con Felix.
	 * En este caso retorna siempre false
	 * @return boolean
	 */
	public boolean colision (Posicion p) { 
		return false;
	}
	
	public void pasarSeccionF(int y) {
		this.getPos().setX(0);
		this.getPos().setY(y);
	}
	@Override
	public String toString() {
		return "FelixJr "+this.grafica;
	}


	
	

}
