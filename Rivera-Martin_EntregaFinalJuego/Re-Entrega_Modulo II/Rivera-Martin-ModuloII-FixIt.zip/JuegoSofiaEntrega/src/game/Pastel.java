package game;


public class Pastel extends Individuo{
	private static final int CONTADOR_INICIAL = 10;
	private int contador;
	private boolean comio;
	
	public Pastel() {
		this.setVisible(false);
		this.contador = CONTADOR_INICIAL;
		this.comio = false;
	}
	
	
	
	public boolean isComio() {
		return comio;
	}

	public void setComio(boolean comio) {
		this.comio = comio;
	}

	/**
	 * M�todo toString que devuelve "Pastel"
	 * @return String
	 */
	public String toString () {
		return "Pastel";
	}
	
	/**
	 * M�todo que si todavia Felix no lo comio y tiene tiempo visible, decrementa el contador hasta que llega a 0
	 * y entonces reinicia el contador y desaparece, al igual que cuando felix lo come
	 */
	public void mover () {
		if (comio) {
			this.setVisible(false);
			contador=CONTADOR_INICIAL;
			comio=false;
		}
		else {
			if (contador != 0) {
				contador -=1;
			}
			else {
				if (this.isVisible()) {
					this.setVisible(false);
					contador = CONTADOR_INICIAL;
				}
			}
		}
		
	}
	
	/**
	 * M�todo que verifica si su posicion coincide con la de Felix, y cambia comio a false
	 * @param p posicion de felix
	 */
	public boolean colision(Posicion p) {
		if (p.equals(this.getPos())) {
			this.comio=true;
			return true;
		}
		else {
			return false;
		}
	}
  
	
	
}