package game;


public class Ladrillo extends Individuo{
	private static final int CONTADOR_INICIAL = 10;
	private int contador;
	
	public Ladrillo () {
		this.setVisible(false);
		this.contador = CONTADOR_INICIAL;
	}


	public int getContador() {
		return contador;
	}

	public void setContador(int contador) {
		this.contador = contador;
	}

	public String toString () {
		return "Ladrillo";
	}
	
	/**
	 * M�todo que mueve el ladrillo de manera vertical y hacia abajo, disminuyendo de a uno
	 */
	public void mover (){
		if (isVisible()) {
			if (this.contador == CONTADOR_INICIAL) {
				this.getPos().setX(Ralph.getInstancia().getPos().getX());
				this.getPos().setY(Ralph.getInstancia().getPos().getY());
				this.contador--;
			}
			else {
				if(this.contador == 0) 
					this.setVisible(false);
				else {
					this.getPos().setY(this.getPos().getY() - 1);
						if(this.colision(FelixJr.getInstancia().getPos())) {
						FelixJr.getInstancia().perderVida();
						this.setVisible(false);
					}
					contador--;
					//Juego.getInstancia().graficar(this.toString());
				}
			}
		}
		
		
		/*
		int x= Ralph.getInstancia().getPos().getX();
		int y= Ralph.getInstancia().getPos().getY();
		this.getPos().setX(x);
		this.getPos().setY(y);
		for (int i = 1; i<3; i++){
			this.getPos().setY(this.getPos().getY()-1);
		}
		*/
	}
	
	
	/**
	 * M�todo que corrobora si su posicion coincide con la de Felix, en caso verdadero retorna true
	 * @param p posicion de fleix 
	 * @return boolean
	 */
	public boolean colision (Posicion p) {
		if(!FelixJr.getInstancia().isInmunidad() && p.equals(this.getPos())) 
				return true;
		else
			return false;
	}
	

}
