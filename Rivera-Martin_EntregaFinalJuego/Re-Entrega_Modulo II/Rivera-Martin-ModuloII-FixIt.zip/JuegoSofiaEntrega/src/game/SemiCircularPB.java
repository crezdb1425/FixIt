package game;

import java.util.Random;

public class SemiCircularPB extends Ventana {

	public SemiCircularPB(int x, int y) {
		this.setAbierta(true);
		this.setEstaRota(false);
		this.setMacetero(false);
		this.setMoldura(false);
		this.getPos().setX(x);
		this.getPos().setY(y);
		this.setPaneles(new Panel[4]);
		for(int i=0; i<this.getPaneles().length;i++) {
			this.getPaneles()[i]=new Panel();
			this.getPaneles()[i].setEstado(Estado.SANO);
		}
	}

	
	
	/**
	 * M�todo que repara los paneles dede el mas inferior a la izquierda, hasta el mas superior a la derecha
	 * 
	 */
	public void reparar () {
		if (this.getPaneles()[0].getEstado() != Estado.SANO) {
			this.reparar(0);
		}
		else {
			if (this.getPaneles()[2].getEstado() != Estado.SANO) {
				this.reparar(2);
			}
			else {
				if (this.getPaneles()[1].getEstado() != Estado.SANO) {
					this.reparar(1);
				}
				else {
					if (this.getPaneles()[3].getEstado() != Estado.SANO) {
						this.getPaneles()[3].setCant_martillazos(this.getPaneles()[3].getCant_martillazos() + 1);
						if (this.getPaneles()[3].getCant_martillazos() == 2) {
							this.getPaneles()[3].setEstado(Estado.SANO);
						}
					 }
				}
			}
		}
		int cantPaneles = 0;
		for (int i=0; i<this.getPaneles().length; i++) {
			if (!this.getPaneles()[i].getEstado().equals(Estado.SANO)) {
				cantPaneles++;
			}
		}
		if (cantPaneles == 0 && this.isEstaRota()) {
			Edificio.getInstancia().getSeccionActual().setCantVentanasRotas(Edificio.getInstancia().getSeccionActual().getCantVentanasRotas()-1);
			this.setEstaRota(false);
			Juego.getInstancia().sumarPuntos(100);
		}
	}
	
	
	
	public String toString() {
		return "Semi";
	}
	
	
	public String [] consultarEstadoPaneles() {
		String [] paneles =new String[this.getPaneles().length];
		for (int i=0; i<this.getPaneles().length;i++) {
			switch(this.getPaneles()[i].getEstado()){
			case SANO:
				paneles[i]="0";
				break;
			default:
				paneles[i]="1";
			}
		}
		return paneles;
	}
	
	public String toStringG() {
		String [] paneles = this.consultarEstadoPaneles();
		return "Semi PB" + " " + paneles[0] + " " + paneles[1] + " " + paneles[2] + " " + paneles[3];
	}
	
	
	
	/**
	 * M�todo que rompe los paneles de manera aleatoria
	 */
	public void inicializarPaneles() {
		Random r =new Random(System.currentTimeMillis());
		int cantP = r.nextInt(3)+1;                             ///      Modificamos el 4 por un 3
		while(cantP>0) {
			for(int i=0; i<this.getPaneles().length;i++) {
				if(this.getPaneles()[i].getEstado().equals(Estado.SANO))
					if(Math.random()<0.5) {
						this.getPaneles()[i].romperPanel();
						cantP--;
					}		
			}
		}
	}



	@Override
	public boolean puedoSalir(Pos dir) {
		// TODO Auto-generated method stub
		return true;
	}



	@Override
	public boolean puedoEntrar(Pos dir) {
		// TODO Auto-generated method stub
		return true;
	}
	
	
	

}
