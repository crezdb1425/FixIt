package game;

import java.lang.Math;
import java.util.Random;

public class Edificio {
	private double cantidadesIniciales = 0.9;
	private int cantidadFilas = 9;
	private int cantidadColumnas = 5;
	private int cantConHojas=10;
	private int cantComunes=35;
	private Seccion seccionActual;
	//private int ventanasRotas;            
	private Ventana dimensionTotal [][]=new Ventana [cantidadFilas][cantidadColumnas];
	private int ventanasAbiertas ;
	private int cantMolduras;
	private int cantMaceteros;
	
	
	private static Edificio instancia = new Edificio();				
	
	public static Edificio getInstancia() {							
		return instancia;											
	}
	
	/**
	 * Constructor de Edificio.
	 * Inicializa la seccion actual en plantabaja, las cantidades iniciales de ventanas rotas, abiertas, molduras y maceteros
	 * Reserva memoria para la matriz de ventanas que conforman el edificio
	 * Elige de manera aleatoria las ventanas comunes/conHojas
	 * Inicializa las ventanas semicirculares en su posicion correspondiente
	 */
	private Edificio () {
		this.seccionActual= Seccion.PLANTABAJA;														
		int x,y;
		Random r = new Random(System.currentTimeMillis());
		for(int i=0;i<cantConHojas;i++) {
			y= r.nextInt(cantidadFilas);
			x= r.nextInt(cantidadColumnas);
			while(dimensionTotal[y][x] != null) {
				y= r.nextInt(cantidadFilas);
				x= r.nextInt(cantidadColumnas);
			}
			dimensionTotal[y][x]=new ConHojas(x, y,cantidadesIniciales);
		}
		for(int j=0;j<cantComunes;j++) {
			y= r.nextInt(cantidadFilas);
			x= r.nextInt(cantidadColumnas);
			while(dimensionTotal[y][x]!=null) {
				y= r.nextInt(cantidadFilas);
				x= r.nextInt(cantidadColumnas);
			}
			dimensionTotal[y][x]=new Comun(x,y);
		}
		
		// creo las unicas dos ventanas semicirculares en el edificio
		dimensionTotal[0][2]= new SemiCircularPB(0,2);
		dimensionTotal[1][2]= new SemiCircular(1,2);
	}
	
	
	
	public double getCantidadesIniciales() {
		return cantidadesIniciales;
	}

	public void setCantidadesIniciales(double cantidadesIniciales) {
		this.cantidadesIniciales = cantidadesIniciales;
	}
	

	public int getVentanasAbiertas() {
		return ventanasAbiertas;
	}

	public void setVentanasAbiertas(int ventanasAbiertas) {
		this.ventanasAbiertas = ventanasAbiertas;
	}

	public int getCantMolduras() {
		return cantMolduras;
	}

	public void setCantMolduras(int cantMolduras) {
		this.cantMolduras = cantMolduras;
	}

	public int getCantMaceteros() {
		return cantMaceteros;
	}

	public void setCantMaceteros(int cantMaceteros) {
		this.cantMaceteros = cantMaceteros;
	}

	public Seccion getSeccionActual() {
		return seccionActual;
	}

	public void setSeccionActual(Seccion seccionActual) {
		this.seccionActual = seccionActual;
	}
	
	public Ventana[][] getDimensionTotal() {
		return dimensionTotal;
	}

	public void setDimensionTotal(Ventana[][] dimensionTotal) {
		this.dimensionTotal = dimensionTotal;
	}
	
	public void repararVentana(Posicion pos) {
		this.dimensionTotal[pos.getY()][pos.getX()].reparar();
	}
	
	public void cambiarSeccion(Seccion seccion) {
		this.seccionActual=seccion;
	}

	
	/**
	 * Metodo que rompe de manera aleatoria las ventanas, misma cantidad en cada seccion. Todo el edificio junto.
	 * Accede por seccion preguntando si no est� rota dicha ventana, con un random decide si romperla o no.
	 */
	public void inicializarVentanas() {
		/* Inicializo la seccion 1 */
			this.iniciarSeccion(Seccion.PLANTABAJA);
			/*for(int j=0;j<3;j++) {
				for(int k=0;k<5;k++) {
					if((!this.dimensionTotal[j][k].isEstaRota())&&(this.dimensionTotal[j][k].isAbierta())) {
						if(Math.random()>cantidadesIniciales) {
							this.dimensionTotal[j][k].setEstaRota(true);
							Seccion.PLANTABAJA.setCantVentanasRotas(Seccion.PLANTABAJA.getCantVentanasRotas()+1);
							this.dimensionTotal[j][k].inicializarPaneles();
	
						}
						else {
							this.dimensionTotal[j][k].setEstaRota(false);
						}
					}
				}
			}*/
		/* Inicializo la seccion 2 */
			this.iniciarSeccion(Seccion.MEDIO);
			/*for(int j=3;j<6;j++) {
				for(int k=0;k<5;k++) {
					if((!this.dimensionTotal[j][k].isEstaRota())&&(this.dimensionTotal[j][k].isAbierta())) {
						if(Math.random()>cantidadesIniciales) {
							this.dimensionTotal[j][k].setEstaRota(true);
							Seccion.MEDIO.setCantVentanasRotas(Seccion.MEDIO.getCantVentanasRotas()+1);
							this.dimensionTotal[j][k].inicializarPaneles();
						
						}
						else {
							this.dimensionTotal[j][k].setEstaRota(false);
						}
					}
				}
			}*/
	
		/* Inicializo la seccion 3 */
			this.iniciarSeccion(Seccion.TERRAZA);
			/*for(int j=6;j<9;j++) {
				for(int k=0;k<5;k++) {
					if((!this.dimensionTotal[j][k].isEstaRota())&&(this.dimensionTotal[j][k].isAbierta())) {
						if(Math.random()>cantidadesIniciales) {
							this.dimensionTotal[j][k].setEstaRota(true);
							Seccion.TERRAZA.setCantVentanasRotas(Seccion.TERRAZA.getCantVentanasRotas()+1);
							this.dimensionTotal[j][k].inicializarPaneles();
			
						}
						else {
							this.dimensionTotal[j][k].setEstaRota(false);
						}
					}
				}
			
			}*/
	}
	
	/**
	 * M�todo que inicializa de manera aleatoria las molduras y los maceteros, utilizando la misma l�gica que inicializarVentanas()
	 */
	public void inicializarMaceteroYMolduras () {																			
		/* Molduras */
			for(int j=0;j<9;j++) {
				for(int k=0; k<5;k++) {
					if( !(this.dimensionTotal[j][k].toString().equals("Semi")) && (!this.dimensionTotal[j][k].isMoldura()) ) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMoldura(false);
						else {
							this.dimensionTotal[j][k].setMoldura(true);
						}
					}
				}
		}
		/* Maceteros */
			for(int j=0;j<9;j++) {
				for(int k=0; k<5;k++) {
					if(!(this.dimensionTotal[j][k].toString().equals("Semi"))&&(this.dimensionTotal[j][k].isMacetero()!=true)) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMacetero(false);
						else {
							this.dimensionTotal[j][k].setMacetero(true);
						}
					}
				}	
			}
	}
	
	
	
	/**
	 * M�todo que le indica al Nicelander qu� ventana tiene el panel inferior completamente roto para poder aparecer
	 * @return Ventana donde podria aparecer el nicelander
	 */
	public Ventana dondeAparecer() {
		return this.buscarVentana(this.seccionActual.getLimiteInferior(), this.seccionActual.getLimiteSuperior());
	}
	
	/**
	 * M�todo que complementa al m�todo dondeAparecer()
	 * Busca la ventana con el panel inferior completamente roto
	 * @param infCol limite inferior de columna en la matriz segun seccion actual
	 * @param supCol limite superior 
	 * @return Ventana
	 */
	public Ventana buscarVentana (int infCol, int supCol) {
		for (int i=Seccion.getLimiteIzquierdo(); i<Seccion.getLimiteDerecho(); i++) {
			for (int j=infCol; j<supCol; j++) {
				if (this.getDimensionTotal()[j][i].puedeAparecerNicelander()) {
					return this.getDimensionTotal()[j][i];
				}
			}
		}
		return null;
	}
	
	public void pasarSeccion() {
		switch (this.seccionActual) {
		case PLANTABAJA:{
			this.setSeccionActual(Seccion.MEDIO);
			FelixJr.getInstancia().pasarSeccionF(3);
			Ralph.getInstancia().getPos().setY(Ralph.getInstancia().getPos().getY()+3);
		}
			break;
		case MEDIO:{
			this.setSeccionActual(Seccion.TERRAZA);
			FelixJr.getInstancia().pasarSeccionF(6);
			Ralph.getInstancia().getPos().setY(Ralph.getInstancia().getPos().getY()+3);
		}
			break;
		case TERRAZA:
			Juego.getInstancia().pasarNivel();
		}
	}
	
	/*
	public void pasarNivel() {
		this.setVentanasAbiertas(this.ventanasAbiertas+(int)(this.ventanasAbiertas*0.1));
		this.setCantMaceteros(this.cantMaceteros+ (int)(this.cantMaceteros*0.1));
		this.setCantMolduras(this.cantMolduras + (int)(this.cantMolduras*0.1));
		//this.setVentanasRotas(this.ventanasRotas + (int)(this.ventanasRotas*0.1));
	}
	*/

	public void pasarNivel() {
		cantidadesIniciales-=cantidadesIniciales*0.1;
		cantConHojas+=3;
		cantComunes-=3;
		this.setDimensionTotal(null);
		this.setDimensionTotal(new Ventana [cantidadFilas][cantidadColumnas]);
		this.seccionActual= Seccion.PLANTABAJA;
		int x,y;
		Random r = new Random(System.currentTimeMillis());
		for(int i=0;i<cantConHojas;i++) {
			y= r.nextInt(cantidadFilas);
			x= r.nextInt(cantidadColumnas);
			while(dimensionTotal[y][x] != null) {
				y= r.nextInt(cantidadFilas);
				x= r.nextInt(cantidadColumnas);
			}
			dimensionTotal[y][x]=new ConHojas(x, y,cantidadesIniciales);
		}
		for(int j=0;j<cantComunes;j++) {
			y= r.nextInt(cantidadFilas);
			x= r.nextInt(cantidadColumnas);
			while(dimensionTotal[y][x]!=null) {
				y= r.nextInt(cantidadFilas);
				x= r.nextInt(cantidadColumnas);
			}
			dimensionTotal[y][x]=new Comun(x,y);
		}
		
		// creo las unicas dos ventanas semicirculares en el edificio
		dimensionTotal[0][2]= new SemiCircularPB(0,2);
		dimensionTotal[1][2]= new SemiCircular(1,2);
		this.inicializarVentanas();
		//this.inicializarMaceteroYMolduras();
	}

	public void iniciarSeccion(Seccion s) {
		switch(s){
		case PLANTABAJA:{
			for(int j=0;j<3;j++) {
				for(int k=0;k<5;k++) {
					if((!this.dimensionTotal[j][k].isEstaRota())&&(this.dimensionTotal[j][k].isAbierta())) {
						if(Math.random()>cantidadesIniciales) {
							this.dimensionTotal[j][k].setEstaRota(true);
							Seccion.PLANTABAJA.setCantVentanasRotas(Seccion.PLANTABAJA.getCantVentanasRotas()+1);
							this.dimensionTotal[j][k].inicializarPaneles();
	
						}
						else {
							this.dimensionTotal[j][k].setEstaRota(false);
						}
					}
				}
			}
			for(int j=0;j<2;j++) {
				for(int k=0; k<5;k++) {
					if( !(this.dimensionTotal[j][k].toString().equals("Semi")) && (!this.dimensionTotal[j][k].isMoldura()) ) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMoldura(false);
						else {
							this.dimensionTotal[j][k].setMoldura(true);
						}
					}
				}
		}
		/* Maceteros */
			for(int j=0;j<2;j++) {
				for(int k=0; k<5;k++) {
					if(!(this.dimensionTotal[j][k].toString().equals("Semi"))&&(this.dimensionTotal[j][k].isMacetero()!=true)) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMacetero(false);
						else {
							this.dimensionTotal[j][k].setMacetero(true);
						}
					}
				}	
			}
		}
		break;
		case MEDIO:{
			for(int j=3;j<6;j++) {
				for(int k=0;k<5;k++) {
					if((!this.dimensionTotal[j][k].isEstaRota())&&(this.dimensionTotal[j][k].isAbierta())) {
						if(Math.random()>cantidadesIniciales) {
							this.dimensionTotal[j][k].setEstaRota(true);
							Seccion.MEDIO.setCantVentanasRotas(Seccion.MEDIO.getCantVentanasRotas()+1);
							this.dimensionTotal[j][k].inicializarPaneles();
						
						}
						else {
							this.dimensionTotal[j][k].setEstaRota(false);
						}
					}
				}
			}
			/* Molduras */
			for(int j=3;j<6;j++) {
				for(int k=0; k<5;k++) {
					if( !(this.dimensionTotal[j][k].toString().equals("Semi")) && (!this.dimensionTotal[j][k].isMoldura()) ) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMoldura(false);
						else {
							this.dimensionTotal[j][k].setMoldura(true);
						}
					}
				}
		}
		/* Maceteros */
			for(int j=3;j<6;j++) {
				for(int k=0; k<5;k++) {
					if(!(this.dimensionTotal[j][k].toString().equals("Semi"))&&(this.dimensionTotal[j][k].isMacetero()!=true)) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMacetero(false);
						else {
							this.dimensionTotal[j][k].setMacetero(true);
						}
					}
				}	
			}
		}
		break;
		case TERRAZA:{
			for(int j=6;j<9;j++) {
				for(int k=0;k<5;k++) {
					if((!this.dimensionTotal[j][k].isEstaRota())&&(this.dimensionTotal[j][k].isAbierta())) {
						if(Math.random()>cantidadesIniciales) {
							this.dimensionTotal[j][k].setEstaRota(true);
							Seccion.TERRAZA.setCantVentanasRotas(Seccion.TERRAZA.getCantVentanasRotas()+1);
							this.dimensionTotal[j][k].inicializarPaneles();
			
						}
						else {
							this.dimensionTotal[j][k].setEstaRota(false);
						}
					}
				}
				
			}
			for(int j=6;j<9;j++) {
				for(int k=0; k<5;k++) {
					if( !(this.dimensionTotal[j][k].toString().equals("Semi")) && (!this.dimensionTotal[j][k].isMoldura()) ) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMoldura(false);
						else {
							this.dimensionTotal[j][k].setMoldura(true);
						}
					}
				}
		}
		/* Maceteros */
			for(int j=6;j<9;j++) {
				for(int k=0; k<5;k++) {
					if(!(this.dimensionTotal[j][k].toString().equals("Semi"))&&(this.dimensionTotal[j][k].isMacetero()!=true)) {
						if(Math.random()<cantidadesIniciales)
							this.dimensionTotal[j][k].setMacetero(false);
						else {
							this.dimensionTotal[j][k].setMacetero(true);
						}
					}
				}	
			}
		}
		}
	}
}
