package game;


public class Pajaro extends Individuo{
	private static final int CONTADOR_INICIAL = 20;
	private Pos dondeAparecer;
	private int contador;

	

	/**
	 * Constructor de pajaro que de manera aleatoria elige por cual fila de ventanas se va a mover
	 */
	public Pajaro () {
		this.setVelocidad(0);
		this.getPos().setX(-99);
		this.getPos().setY(-99);
		this.setVisible(false);
		this.contador = CONTADOR_INICIAL;
		this.dondeAparecer = Pos.DERECHA;
	}

	

	public Pos getDondeAparecer() {
		return dondeAparecer;
	}


	public void setDondeAparecer(Pos dondeAparecer) {
		this.dondeAparecer = dondeAparecer;
	}

	public String toString() {
		return "Pajaro";
	}
	
	
	public String toStringG () {
		if (this.dondeAparecer.equals(Pos.DERECHA)) {
			return "Pajaro Derecha " + this.contador%2;
		}
		else {
			return "Pajaro Izquierda " + this.contador%2;
		}
	}
	
	
	/**
	 * M�todo que, a partir de la fila de ventana inicial indicada por inicializar(), decide 
	 * si a apartir de la derecha o izquierda aparece y comienza a avanzar 
	 */
	public void mover () {
		if (Edificio.getInstancia().getSeccionActual() != Seccion.PLANTABAJA){
			if (!this.isVisible()) {
				if (Math.random() > 0.9) {
					this.setVisible(true);
					double ran = Math.random()*3;
					if (Edificio.getInstancia().getSeccionActual() == Seccion.MEDIO) {
						if (ran < 1) {
							this.getPos().setY(3);
						}
						else {
							if (ran < 2) {
								this.getPos().setY(4);
							}
							else {
								this.getPos().setY(5);
							}
						}
					
					}
					else {
						if (ran < 1) {
							this.getPos().setY(6);
						}
						else {
							if (ran < 2) {
								this.getPos().setY(7);
							}
							else {
								this.getPos().setY(8);
							}
					}
				}
				if (Math.random() < 0.5) {
					this.getPos().setX(0);
					this.dondeAparecer = Pos.IZQUIERDA;
					for (int i = 0; i < 4; i++) {
						this.getPos().calcularMovimiento(Pos.DERECHA);
						}
				}
				else {
					this.dondeAparecer=Pos.DERECHA;
					this.getPos().setX(4);
					for (int i = 0; i < 4; i++) {
						this.getPos().calcularMovimiento(Pos.IZQUIERDA);						
						}
					}
				}
			}
			else {
				if (contador != 0) {
					this.getPos().calcularMovimiento(this.dondeAparecer);
					this.contador--;
				}
				else {
					this.setVisible(false);
					this.contador = CONTADOR_INICIAL;
				}
			}
		}
	}
	
	

	/**
	 * M�todo que corrobora si su posicion coincide con la de Felix
	 * @param p posicion de felix
	 * @return boolean true, si coincide, false caso contrario
	 */
	public boolean colision (Posicion p) {
		if (p.equals(this.getPos())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
}