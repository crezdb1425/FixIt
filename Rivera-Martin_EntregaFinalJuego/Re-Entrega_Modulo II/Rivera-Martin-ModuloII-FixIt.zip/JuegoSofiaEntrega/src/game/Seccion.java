package game;

public enum Seccion {
	PLANTABAJA(0,2), MEDIO(3,5), TERRAZA(6,8);
	

	
	private static int limiteDerecho = 4;
	private static int limiteIzquierdo = 0;
	
	private int limiteInferior;
	private int limiteSuperior;
	private int cantVentanasRotas=0;
	
	
	
	private Seccion(int limiteInf, int limiteSup) {
		this.limiteInferior=limiteInf;
		this.limiteSuperior = limiteSup;
		
	}
	
	
	
	public int getCantVentanasRotas() {
		return cantVentanasRotas;
	}



	public void setCantVentanasRotas(int cantVentanasRotas) {
		this.cantVentanasRotas = cantVentanasRotas;
	}



	public static int getLimiteDerecho() {
		return limiteDerecho;
	}
	public static void setLimiteDerecho(int limiteDerecho) {
		Seccion.limiteDerecho = limiteDerecho;
	}
	public static int getLimiteIzquierdo() {
		return limiteIzquierdo;
	}
	public static void setLimiteIzquierdo(int limiteIzquierdo) {
		Seccion.limiteIzquierdo = limiteIzquierdo;
	}


	public int getLimiteInferior() {
		return limiteInferior;
	}


	public void setLimiteInferior(int limiteInferior) {
		this.limiteInferior = limiteInferior;
	}


	public int getLimiteSuperior() {
		return limiteSuperior;
	}


	public void setLimiteSuperior(int limiteSuperior) {
		this.limiteSuperior = limiteSuperior;
	}
	
	
}
