package game;

import java.util.concurrent.CopyOnWriteArrayList;

import controlador.ControladorRanking;



public class Juego {
	private int nivelActual;
	private int puntaje;
	private double tiempoTotal;          // para jugar 
	private double tiempo;				// transcurrido
	private Edificio edif;
	private boolean over;
	private CopyOnWriteArrayList<Individuo> individuos = new CopyOnWriteArrayList<Individuo>();
	static final double PORCENTAJE_AUMENTO = 0.1;
	static final int TIEMPO_TOTAL = 90;
	static final int VIDAS_INICIALES = 3;
	static final int PUNTOS_SECCION = 400;
	static final int NIVEL_GANAR = 11;
	static final double CTE_CAMBIO_TIEMPO = 1/2;
	static final int PUNTAJE_INICIAL = 0;
	static final int TIEMPO_INICIAL = 0;
	
	private static Juego instancia = new Juego();


	public static Juego getInstancia() {
		return instancia;
	}
	
	/**
	 * Constructor de la clase Juego
	 * Inicializa las variables nivel actual(1), puntaje(0), reservar memoria para vector del Ranking, inicializar tiempo total(100), 
	 * inicializar variable over (false) que indica cuando se termina el juego 
	 */
	public Juego () {
		this.nivelActual=1;
		this.puntaje=0;	
		this.tiempoTotal=TIEMPO_TOTAL;
		this.tiempo=0;
		this.over=false;
	};
	
	
	public int getNivelActual() {
		return nivelActual;
	}


	public void setNivelActual(int nivelActual) {
		this.nivelActual = nivelActual;
	}


	public int getPuntaje() {
		return puntaje;
	}


	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}


	public double getTiempoTotal() {
		return tiempoTotal;
	}


	public void setTiempoTotal(int tiempoTotal) {
		this.tiempoTotal = tiempoTotal;
	}


	public double getTiempo() {
		return tiempo;
	}


	public void setTiempo(int t) {
		this.tiempo = t;
	}


	public Edificio getEdif() {
		return edif;
	}


	public void setEdif(Edificio edif) {
		this.edif = edif;
	}

	
	public boolean isOver() {
		return over;
	}

	public void setOver(boolean over) {
		this.over = over;
	}

	public CopyOnWriteArrayList<Individuo> getIndividuos() {
		return individuos;
	}

	public void setIndividuos(CopyOnWriteArrayList<Individuo> individuos) {
		this.individuos = individuos;
	}
	
	

	/**
	 * M�todo que aumenta el tiempo transcurrido
	 */
	public void sumarTiempo () {  
		this.tiempo += 1;
	}
	
	/**
	 * M�todo que repara la ventana de la posicion pos
	 * @param pos posicion de la ventana a reparar
	 */
	public void repararVentana(Posicion pos) {
		Edificio.getInstancia().repararVentana(pos);
	}
	
	
	/**
	 * M�todo que incrementa el nivel actual, disminuye en un 10% el tiempo total para jugar y aumenta en un 10%: cantidad de ventanas abiertas, cantidad de maceteros,
	 * cantidad de molduras, cantidad de ventanas rotas y la cantidad de ladrillos que tiene Ralph.
	 */
	public void pasarNivel() {
		this.nivelActual++;
		FelixJr.getInstancia().setVidas(VIDAS_INICIALES);
		this.tiempoTotal-=(this.tiempoTotal*PORCENTAJE_AUMENTO);
		edif.pasarNivel();
		Ralph.getInstancia().pasarNivel();
		FelixJr.getInstancia().pasarNivel();


		///////////////////////////// hay que posicionar a felix y ralph e vuelta
		
	}



	
	/**
	 * M�todo que se ejecuta al ganar el juego
	 */
	public void victoria () {
		System.out.println("Felicitaciones ganaste!! Ujuuuu");
		this.over=true;
		System.out.println(this.puntaje);
		new ControladorRanking();
	}
	
	/**
	 * M�todo que se ejecuta al perder el juego
	 */
	public void gameOver () {
		System.out.println("Buuuu Perdiste!!!");
		this.over = true;
		new ControladorRanking();
	}


	/**
	 * M�todo que suma al puntaje actual una cantidad p de puntos
	 * @param p puntaje a sumar
	 */
	public void sumarPuntos(int p) {
		this.setPuntaje(this.getPuntaje() + p);
	}
	

	/**
	 * M�todo que inicializa todas las ventanas del edificio del nivel actual
	 */
	public void inicializarVentana() {
		Edificio.getInstancia().inicializarVentanas();
	}
	
	
	/**
	 * M�todo que reinicia la seccion actual, 
	 */
	public void reiniciarSeccion() {
		edif.iniciarSeccion(edif.getSeccionActual());
	}
	
	
	
	/**
	 * M�todo que pasa de seccion
	 */
	public void pasarSeccion () {
		edif.pasarSeccion();
		//Ralph.getInstancia().getPos().setY(Ralph.getInstancia().getPos().getY()+3);
		this.setPuntaje(this.getPuntaje() + PUNTOS_SECCION);
	}



	/**
	 * M�todo que inicializa un nivel, poniendo la seccion actual en planta baja, posicionando a felix y ralph nuevamnte al inicio.
	 */
	public void inicializarNivel() {
		Edificio.getInstancia().setSeccionActual(Seccion.PLANTABAJA);
		this.reiniciarSeccion();
		FelixJr.getInstancia().getPos().setX(0);
		FelixJr.getInstancia().getPos().setY(0);
		Ralph.getInstancia().getPos().setX(0);
		Ralph.getInstancia().getPos().setY(3);
	}

	public void reiniciarNivel() {
		this.inicializarVentana();
		this.inicializarObstaculos();
		this.inicializarNivel();
	}

	/**
	 * Metodo que invoca al metodo de edificio para inicializar maceteros y molduras
	 */
	public void inicializarObstaculos() {
		Edificio.getInstancia().inicializarMaceteroYMolduras();
	}
	
	
	
	/*//////////////////////////////////////// Se agrego /////////////////////////////////////// */	
	
	/**
	 * M�todo que reinicia la seccion al Felix chocar pajaro
	 */
	public void chocarPajaro() {
		this.reiniciarSeccion();
		//FelixJr.getInstancia().chocar();
		FelixJr.getInstancia().getPos().setX(0);
		switch(edif.getSeccionActual()) {
		case MEDIO:
			FelixJr.getInstancia().getPos().setY(3);
			break;
		case TERRAZA:
			FelixJr.getInstancia().getPos().setY(6);
		}
	}
	
	/**
	 * M�todo que corrobora si un pajaro, ladrillo o pastel coincide su posicion con la de Felix
	 */
	public void colision () {
		for (Individuo i : individuos) {
			boolean colision = i.colision(FelixJr.getInstancia().getPos());
			switch (i.toString()) {
			case "Pajaro":
					if(!FelixJr.getInstancia().isInmunidad())
					if (colision) {
						this.chocarPajaro();
						i.setVisible(false);
					}
				break;
			case "Nicelander":
				if (colision)
					FelixJr.getInstancia().comerPastel();
				break;
			}
		}
	}
	
	/**
	 * M�todo que se ejecuta en cada instante haciendo los chequeos correspondientes, como: si hubo colision, si se paso de nivel, si se perdio ya sea 
	 * por quedarse sin vidas o por terminarse el tiempo o si se gano
	 */
	public void actualizar () {
		if (this.nivelActual == NIVEL_GANAR) {
			this.victoria();
		}
		for (Individuo i : individuos ) {
			i.mover();
			i.actualizar();
		}
		this.colision();
	
		
		if (FelixJr.getInstancia().getVidas() == 0) {
			this.gameOver();
			System.out.println("Te quedaste sin vidas!!");
		}
		if(this.edif.getSeccionActual().getCantVentanasRotas()==0)
			this.pasarSeccion();
		
		this.tiempo +=CTE_CAMBIO_TIEMPO;			// Estos dependen de cuanto es un segundo por ejecucion
		
		if (tiempoTotal == tiempo) {
			this.gameOver();
			System.out.println("Se te termin� el tiempo!!");
		}
	}
	/* //////////////////////////////////////////////////////////////////////////////////////////////////////////////// */
	
	/**
	 * M�todo que se ejecuta antes que comience el juego. Crea las instancias de los individuos, asi como inicializa los tiempos, el puntaje, e inicializa 
	 * las ventanas y los obstaculos.
	 */
	public void comenzar (int nivel) {
		edif=Edificio.getInstancia();
		System.out.println("Iniciaste en el nivel "+nivel);
		for (int i=0; i<nivel-1; i++) {
			edif.setCantidadesIniciales(edif.getCantidadesIniciales()-edif.getCantidadesIniciales()*PORCENTAJE_AUMENTO);
		}
		this.individuos.add(Ralph.getInstancia());
		this.individuos.add(FelixJr.getInstancia());
		for (int i=0; i<2; i++) {
			this.individuos.add(new Pajaro());
			this.individuos.add(new Nicelander());
		}
		edif=Edificio.getInstancia();
		this.over = false;
		this.setTiempo(TIEMPO_INICIAL);
		this.setTiempoTotal(TIEMPO_TOTAL);					
		this.setPuntaje(PUNTAJE_INICIAL);
		this.setNivelActual(nivel);
		this.inicializarNivel();					
		this.inicializarVentana();					
		this.inicializarObstaculos();		
	}
	
	
	
}