package game;

public enum Pos {
	ARRIBA, ABAJO, DERECHA, IZQUIERDA;
}
