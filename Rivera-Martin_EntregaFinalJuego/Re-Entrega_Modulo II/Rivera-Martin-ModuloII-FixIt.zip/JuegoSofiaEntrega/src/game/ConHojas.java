package game;

import java.util.Random;


/* Se abre a la izquierda */


public class ConHojas extends Ventana{
	


	public ConHojas(int x, int y, double cantidadesIniciales) {
		if(Math.random()>cantidadesIniciales) 
			this.setAbierta(true);
		else
			this.setAbierta(false);
		this.setEstaRota(false);
		this.setMacetero(false);
		this.setMoldura(false);
		this.getPos().setX(x);
		this.getPos().setY(y);
		this.setPaneles(new Panel[2]);
		for(int i=0; i<this.getPaneles().length;i++) {
			this.getPaneles()[i]=new Panel();
			this.getPaneles()[i].setEstado(Estado.SANO);
		}
	}

	
	
	/**
	 * M�todo que repara los paneles de la ventana si estan abiertas.
	 * Si el panel inferior(par) no est� sano, se llama al metodo reparar() de la superclase ventana
	 * Sino, se pregunta por el superior, si no esta sano, se sigue la misma logica que antes y ademas suma 100ptos y se resta la cantidad
	 * de ventanas rotas actual del edificio
	 */
	public void reparar () {
		if (this.isAbierta()) {		
			if (this.getPaneles()[0].getEstado() != Estado.SANO) {
				this.reparar(0);
			}
			else {
				if (this.getPaneles()[1].getEstado()!=Estado.SANO) {
					this.reparar(1);
					}
				}
			}
		int cantPaneles = 0;
		for (int i=0; i<this.getPaneles().length; i++) {
			if (!this.getPaneles()[i].getEstado().equals(Estado.SANO)) {
				cantPaneles++;
			}
		}
		if (cantPaneles==0 && this.isEstaRota()) {
			Edificio.getInstancia().getSeccionActual().setCantVentanasRotas(Edificio.getInstancia().getSeccionActual().getCantVentanasRotas()-1);
			this.setEstaRota(false);
			Juego.getInstancia().sumarPuntos(100);
		}
		}
	
	
	/**
	 * M�todo que devuelve un String = Hojas
	 * @return String
	 */
	public String toString() {
		return "Hojas";
	}
	
	

	public String toStringG() {
		String[] paneles= this.consultarEstadoPaneles();
		String abierta;
		if(this.isAbierta())
			abierta="A";
		else
			abierta= "C";
		return (this.toString()+ " "+abierta+ " " +paneles[0]+ " " +paneles[1]);
	}
	
	
	/**
	 * M�todo que rompe los paneles de maneta aleatoria
	 */
	public void inicializarPaneles() {
		if(this.isAbierta()) {
				Random r = new Random (System.currentTimeMillis());
				int cantP = r.nextInt(2)+1;
				int posPanel = r.nextInt(2);
				switch(cantP){
				case (1):{
					this.getPaneles()[posPanel].romperPanel();
				}
				case (2):{
					this.getPaneles()[0].romperPanel();
					this.getPaneles()[1].romperPanel();
				}
				}
			}
		}
	
	
	public boolean puedeAparecerNicelander() {
		if (this.getPaneles()[0].getEstado() == Estado.ROTO && this.isAbierta()) {
			return true;
		}
		else 
			return false;
	}

	/**
	 * Metodo que devuelve true a Felix si es posible para el moverse en todas las direcciones
	 * dependiendo si hay moldura, macetero o las persianas estan abiertas
	 * @param dir direccion en la que se deberia mover felix
	 * @return boolean
	 */
	public boolean puedoSalir (Pos dir) {
		switch(dir) {
		case ARRIBA:{
			if(this.isMoldura())
				return false;
			else
				return true;
		}
		case ABAJO:{
			if(this.isMacetero())
				return false;
			else
				return true;
		}
		case IZQUIERDA:{
			if(this.isAbierta())
				return false;
			else
				return true;
		}
		case DERECHA:{
			return true;
		}
		default:
			return true;
		}
	}
	
	
	/**
	 * Metodo que devuelve true a Felix si es posible para el moverse en todas las direcciones
	 * dependiendo si hay moldura, macetero o las persianas estan abiertas
	 * @param dir direccion en la que se deberia mover felix
	 * @return boolean
	 */
	public boolean puedoEntrar (Pos dir) {
		switch(dir) {
		case ARRIBA:{
			if(this.isMacetero())
				return false;
			else
				return true;
		}
		case ABAJO:{
			if(this.isMoldura())
				return false;
			else
				return true;
		}
		case IZQUIERDA:{
			return true;
		}
		case DERECHA:{
			if(this.isAbierta())
				return false;
			else
				return true;
		}
		default: 
			return true;
		}
	}
	
}
